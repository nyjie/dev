package com.hand.hap.cloud.devops;

//import com.han.event.consumer.helper.MessageQueue;
//import com.han.event.consumer.helper.QueueType;
import com.hand.event.consumer.helper.MessageQueue;
import com.hand.event.consumer.helper.QueueType;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.netflix.feign.EnableFeignClients;

/**
 * Created by HuangFuqiang on 2017/11/4.
 */
@EnableEurekaClient
@SpringBootApplication
@EnableFeignClients
@MessageQueue(value = QueueType.rabbitmq,
        enableDuplicateRemoveByUuid = false,
        enableCache = false)
public class DevopsServiceApplication {

    public static void main(String[] args){
        SpringApplication.run(DevopsServiceApplication.class, args);
    }

}
