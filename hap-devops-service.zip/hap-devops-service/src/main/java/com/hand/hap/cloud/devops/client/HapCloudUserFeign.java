package com.hand.hap.cloud.devops.client;

import com.hand.hap.cloud.devops.client.impl.HystrixClientFallback;
import com.hand.hap.cloud.devops.domain.service.HapcloudProject;
import com.hand.hap.cloud.devops.domain.user.UserProcMsg;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

/**
 * Created with IntelliJ IDEA.
 * Description:
 * UserProcMsg: huangfengrun
 * Date: 2017-11-07
 */

@FeignClient(value = "hap-user-service", fallback=HystrixClientFallback.class)
public interface HapCloudUserFeign {

    @RequestMapping(value = "/v1/organization/{organizationId}/projects/{projectId}",method = RequestMethod.GET)
    ResponseEntity<HapcloudProject> queryHapcloudProject(@PathVariable("organizationId") Long organizationId,
                                                         @PathVariable("projectId") Long projectId);

    @RequestMapping(value = "/v1/organization/{organizationId}/projects",method = RequestMethod.POST)
    ResponseEntity<HapcloudProject> crete(@PathVariable("organizationId") Long organizationId,
                                  @RequestBody @Validated HapcloudProject project);

    @RequestMapping(value = "/v1/organization/{organizationId}/projects/{projectId}",method = RequestMethod.DELETE)
    ResponseEntity delete(@PathVariable("organizationId") Long organizationId,
                          @PathVariable("projectId") Long projectId);

    @RequestMapping(value = "/v1/organization/{organizationId}/projects/{projectId}",method = RequestMethod.PUT)
    ResponseEntity<HapcloudProject> update(@PathVariable("organizationId") Long organizationId,
                                   @PathVariable("projectId") Long projectId,
                                   @RequestBody HapcloudProject project);
}
