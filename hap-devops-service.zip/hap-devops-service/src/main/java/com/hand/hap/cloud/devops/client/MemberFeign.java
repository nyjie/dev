package com.hand.hap.cloud.devops.client;

import com.hand.hap.cloud.devops.client.impl.HystrixClientFallback;
import com.hand.hap.cloud.devops.domain.gitlab.Member;
import com.hand.hap.cloud.devops.domain.gitlab.User;
import com.hand.hap.cloud.devops.domain.usermember.UserMemberProcMsg;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@FeignClient(value = "hap-gitlab-service", fallback=HystrixClientFallback.class)
public interface MemberFeign {

    @RequestMapping(value = "/v1/user/queryUserByUsername",method = RequestMethod.GET)
    ResponseEntity<User> queryUserByUsername(@RequestParam("userName") String userName);

    @RequestMapping(value = "/v1/project/select/group/{groupId}/member/{userId}",method = RequestMethod.GET)
    ResponseEntity<Member> queryGroupMember(
                                                   @PathVariable("groupId") Integer groupId,
                                                   @PathVariable("userId") Integer userId);

    @RequestMapping(value = "/v1/project/add/groupMember",method = RequestMethod.POST)
    ResponseEntity addMember(
                                    @RequestParam("groupId") Integer groupId,
                                    @RequestParam("userId") Integer userId,
                                    @RequestParam("accessLevel") Integer accessLevel,
                                    @RequestParam("expiresAt") String expiresAt);

    @RequestMapping(value = "/v1/project/update/groupMember",method = RequestMethod.PUT)
    ResponseEntity updateMember(
                                       @RequestParam("groupId") Integer groupId,
                                       @RequestParam("userId") Integer userId,
                                       @RequestParam("accessLevel") Integer accessLevel,
                                       @RequestParam("expiresAt") String expiresAt);

    @RequestMapping(value = "/v1/project/remove/group/{groupId}/member/{userId}",method = RequestMethod.DELETE)
    ResponseEntity removeMember(
                                       @PathVariable("groupId") Integer groupId,
                                       @PathVariable("userId") Integer userId);
}

