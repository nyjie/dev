package com.hand.hap.cloud.devops.client;

import com.hand.hap.cloud.devops.client.impl.HystrixClientFallback;
import com.hand.hap.cloud.devops.domain.gitlab.Group;
import com.hand.hap.cloud.devops.domain.project.ProjectProcMsg;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
@FeignClient(value="hap-gitlab-service", fallback = HystrixClientFallback.class)
public interface ProjectFeign {
    @RequestMapping(value = "/v1/organization/AddProject", method = RequestMethod.POST)
    ResponseEntity<Group> addProject(
                              @RequestParam("projectCode") String code,
                              @RequestParam("projectName") String name
    );

    @RequestMapping(value = "/v1/organization/UpdateProject", method = RequestMethod.PUT)
    ResponseEntity updateProject(
                    @RequestParam("groupId") Integer groupId,
                    @RequestParam("newProjectCode") String newProjectCode,
                    @RequestParam("newProjectName") String newProjectName
    );

    @RequestMapping(value = "/v1/organization/DeleteProject", method = RequestMethod.PUT)
    ResponseEntity dateleProject(
            @RequestParam("groupId") Integer groupId
    );

}
