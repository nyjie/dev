package com.hand.hap.cloud.devops.client;

import com.hand.hap.cloud.devops.client.impl.HystrixClientFallback;
import com.hand.hap.cloud.devops.domain.gitlab.Project;
import com.hand.hap.cloud.devops.domain.service.DevopsService;
import com.hand.hap.cloud.devops.domain.service.HapcloudProject;
import com.hand.hap.cloud.devops.domain.service.ServiceProcMsg;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@FeignClient(value = "hap-gitlab-service", fallback=HystrixClientFallback.class)
public interface ServiceFeign {

    @RequestMapping(value = "/v1/service/createProject",method = RequestMethod.POST)
    ResponseEntity<Project> createProject(@RequestParam("groupId") Integer groupId,
                                          @RequestParam("projectName") String projectName);
    
    @RequestMapping(value = "/v1/service/updateProject",method = RequestMethod.PUT)
    ResponseEntity<Project> updateProject(@RequestParam("gitlabProjectId")Integer gitlabProjectId,
                                          @RequestParam("projectCode") String projectCode);

    @RequestMapping(value = "/v1/service/addVariable",method = RequestMethod.POST)
    ResponseEntity addVariable(@RequestParam("gitlabProjectId") Integer gitlabProjectId,
                               @RequestParam("key") String key,
                               @RequestParam("value") String value,
                               @RequestParam("protecteds") boolean  protecteds);

    @RequestMapping(value = "/v1/service/deleteProject",method = RequestMethod.DELETE)
    ResponseEntity deleteProject(@RequestParam("gitlabProjectId") Integer gitlabProjectId);
}
