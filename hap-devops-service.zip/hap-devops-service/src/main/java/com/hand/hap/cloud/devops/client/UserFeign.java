package com.hand.hap.cloud.devops.client;

import com.hand.hap.cloud.devops.client.impl.HystrixClientFallback;
import com.hand.hap.cloud.devops.domain.user.UserProcMsg;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * Created with IntelliJ IDEA.
 * Description:
 * UserProcMsg: huangfengrun
 * Date: 2017-11-07
 */

@FeignClient(value = "hap-gitlab-service", fallback=HystrixClientFallback.class)
public interface UserFeign {
    @RequestMapping(value = "/v1/user/create", method = RequestMethod.POST)
    ResponseEntity createGitLabUser(@RequestBody UserProcMsg userProcMsg,
                                    @RequestParam("password") String password,
                                    @RequestParam("projectsLimit") Integer projectsLimit);

    @RequestMapping(value = "/v1/user/deleteUser", method = RequestMethod.DELETE)
    ResponseEntity deleteGitLabUser(@RequestParam("username") String username);

    @RequestMapping(value = "/v1/user/alertUser", method = RequestMethod.PUT)
    ResponseEntity modifyGitLabUser(@RequestBody UserProcMsg userProcMsg,
                             @RequestParam("password") String password,
                             @RequestParam("projectsLimit") Integer projectsLimit);


}
