package com.hand.hap.cloud.devops.client.impl;

import com.hand.hap.cloud.devops.client.*;
import com.hand.hap.cloud.devops.domain.gitlab.Group;
import com.hand.hap.cloud.devops.domain.gitlab.Member;
import com.hand.hap.cloud.devops.domain.gitlab.Project;
import com.hand.hap.cloud.devops.domain.gitlab.User;
import com.hand.hap.cloud.devops.domain.project.ProjectProcMsg;
import com.hand.hap.cloud.devops.domain.service.DevopsService;
import com.hand.hap.cloud.devops.domain.service.HapcloudProject;
import com.hand.hap.cloud.devops.domain.service.ServiceProcMsg;
import com.hand.hap.cloud.devops.domain.user.UserProcMsg;
import com.hand.hap.cloud.devops.domain.usermember.UserMemberProcMsg;
import com.hand.hap.cloud.resource.exception.HapException;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

@Component
public class HystrixClientFallback implements MemberFeign,UserFeign,ProjectFeign,ServiceFeign,HapCloudUserFeign{
    @Override
    public ResponseEntity<Project> createProject(Integer groupId, String projectName) {
        throw new HapException("error.create.project");
    }

    @Override
    public ResponseEntity addVariable(Integer gitlabProjectId, String key, String value, boolean protecteds) {
        throw new HapException("error.add.variable");
    }

    @Override
    public ResponseEntity createGitLabUser(UserProcMsg userProcMsg, String password, Integer projectsLimit) {
        throw new HapException("error.userProcMsg.create");
    }

    @Override
    public ResponseEntity deleteGitLabUser(String username) {
        return null;
    }

    @Override
    public ResponseEntity modifyGitLabUser(UserProcMsg userProcMsg, String password, Integer projectsLimit) {
        throw new HapException("error.userProcMsg.modify");
    }

    @Override
    public ResponseEntity<Group> addProject(String code, String name) {
        throw new HapException("error.project.add");
    }

    @Override
    public ResponseEntity updateProject(Integer groupId,String newProjectCode,String newProjectName) {
        throw new HapException("error.project.update");
    }

    @Override
    public ResponseEntity dateleProject(Integer groupId) {
        throw new HapException("error.project.delete");
    }


    @Override
    public ResponseEntity<Project> updateProject(Integer gitlabProjectId, String projectCode) {
        throw new HapException("error.service.update");
    }

    @Override
    public ResponseEntity deleteProject(Integer gitlabProjectId) {
        throw new HapException("error.service.delete");
    }

    @Override
    public ResponseEntity<HapcloudProject> queryHapcloudProject(Long organizationId, Long projectId) {
        throw new HapException("error.query.project");
    }

    @Override
    public ResponseEntity<HapcloudProject> crete(Long organizationId, HapcloudProject project) {
        return null;
    }

    @Override
    public ResponseEntity delete(Long organizationId, Long projectId) {
        return null;
    }

    @Override
    public ResponseEntity<HapcloudProject> update(Long organizationId, Long projectId, HapcloudProject project) {
        return null;
    }

    @Override
    public ResponseEntity<User> queryUserByUsername( String userName) {
        throw new HapException("error.user.get");
    }

    @Override
    public ResponseEntity<Member> queryGroupMember( Integer groupId, Integer userId) {
        throw new HapException("error.group.member.get");
    }

    @Override
    public ResponseEntity addMember( Integer groupId, Integer userId, Integer accessLevel, String expiresAt) {
        throw new HapException("error.add.member");
    }

    @Override
    public ResponseEntity updateMember( Integer groupId, Integer userId, Integer accessLevel, String expiresAt) {
        throw new HapException("error.update.member");
    }

    @Override
    public ResponseEntity removeMember( Integer groupId, Integer userId) {
        throw new HapException("error.remove.member");
    }
}
