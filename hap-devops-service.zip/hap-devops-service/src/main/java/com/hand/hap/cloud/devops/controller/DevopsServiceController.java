package com.hand.hap.cloud.devops.controller;

import com.hand.hap.cloud.devops.domain.service.DevopsService;
import com.hand.hap.cloud.devops.service.DevopsServiceService;
import com.hand.hap.cloud.mybatis.pagehelper.domain.Page;
import com.hand.hap.cloud.resource.exception.HapException;
import com.hand.hap.cloud.swagger.annotation.Permission;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping(value = "/v1")
public class DevopsServiceController {
    @Autowired
    private DevopsServiceService devopsServiceService;


    @Permission(level = "project", roles = {"projectOwner","projectMember"})
    @ApiOperation(value = "创建服务")
    @RequestMapping(value = "/project/{projectId}/addDevopsService", method = RequestMethod.POST)
    public ResponseEntity<DevopsService> createDevopsService(@PathVariable("projectId") Long projectId,@RequestParam("organizationId") Long organizationId, @RequestBody DevopsService devopsService) {
        return Optional.ofNullable(devopsServiceService.create(organizationId,projectId,devopsService))
                .map(result -> new ResponseEntity<>(result, HttpStatus.CREATED))
                .orElseThrow(() -> new HapException("error.service.create"));
    }

    @Permission(level = "project", roles = {"projectOwner","projectMember"})
    @ApiOperation(value = "修改服务")
    @RequestMapping(value = "/project/{projectId}/updateDevopsService", method = RequestMethod.PUT)
    public ResponseEntity<DevopsService> updateDevopsService(@PathVariable Long projectId,
                                                             @RequestParam("serviceId") Long serviceId,
                                                             @RequestParam("code") String code,
                                                             @RequestParam("name") String name) {
        return Optional.ofNullable(devopsServiceService.update(serviceId, code, name))
                .map(result -> new ResponseEntity<>(result, HttpStatus.CREATED))
                .orElseThrow(() -> new HapException("error.service.create"));
    }

    @Permission(level = "project", roles = {"projectOwner","projectMember"})
    @ApiOperation(value = "删除服务")
    @RequestMapping(value = "/project/{projectId}/service/{serviceId}", method = RequestMethod.DELETE)
    public ResponseEntity deleteDevopsService(@PathVariable Long projectId, @PathVariable Long serviceId) {
        if (devopsServiceService.delete(projectId, serviceId)) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } else {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    @Permission(level = "project", roles = {"projectOwner", "projectMember", "releaseAdmin"})
    @ApiOperation(value = "分页查询所有服务")
    @RequestMapping(value = "/project/{projectId}/pageService", method = RequestMethod.GET)
    public Page<DevopsService> pageDevopsService(@PathVariable @Valid Long projectId,
                                                 @RequestParam Long organizationId,
                                                 @RequestParam Integer page,
                                                 @RequestParam Integer size) {
        return devopsServiceService.pageDevopsService(projectId, organizationId, page, size);
    }

    @Permission(level = "project", roles = {"projectOwner", "projectMember", "releaseAdmin"})
    @ApiOperation(value = "查询服务详情")
    @RequestMapping(value = "/project/{projectId}/service/{serviceId}", method = RequestMethod.GET)
    public List<DevopsService> selectDevopsService(@PathVariable @Valid Long projectId,
                                                   @RequestParam Long organizationId,
                                                   @PathVariable @Valid Long serviceId) {
        return devopsServiceService.selectDevopsService(projectId,organizationId,serviceId);
    }

    @Permission(level = "project", roles = {"projectOwner", "projectMember", "releaseAdmin"})
    @ApiOperation(value = "查询服务name")
    @RequestMapping(value = "/project/{projectId}/selectService/name", method = RequestMethod.GET)
    public boolean selectDevopsServiceParamName(@PathVariable @Valid Long projectId,
                                                @RequestParam String name) {
        return devopsServiceService.selectDevopsServiceParamName(projectId,name);
    }

    @Permission(level = "project", roles = {"projectOwner", "projectMember", "releaseAdmin"})
    @ApiOperation(value = "查询服务code")
    @RequestMapping(value = "/project/{projectId}/selectService/code", method = RequestMethod.GET)
    public boolean selectDevopsServiceParamCode(@PathVariable @Valid Long projectId,
                                                @RequestParam String code) {
        return devopsServiceService.selectDevopsServiceParamCode(projectId,code);
    }

    @Permission(level = "organization", roles = {"projectOwner", "projectMember", "releaseAdmin"})
    @ApiOperation(value = "查询项目下service列表")
    @RequestMapping(value = "/project/{projectId}/service",method = RequestMethod.GET)
    public List<DevopsService> queryProjectService(@PathVariable Long projectId,
                                                   @RequestParam Long organizationId){
        return devopsServiceService.queryProjectService(projectId,organizationId);
    }
}
