package com.hand.hap.cloud.devops.controller;

import com.hand.hap.cloud.devops.domain.environment.Environment;
import com.hand.hap.cloud.devops.service.EnvironmentService;
import com.hand.hap.cloud.mybatis.pagehelper.domain.Page;
import com.hand.hap.cloud.resource.exception.HapException;
import com.hand.hap.cloud.swagger.annotation.Permission;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

/**
 * Created by qs on 2017/11/15.
 */
@RestController
@RequestMapping(value = "/v1/organization/{organizationId}")
public class EnvironmentController {

    @Autowired
    private EnvironmentService environmentService;

    @Permission(permissionLogin = true)
    @GetMapping(value = "/we")
    public String str(@PathVariable Long organizationId){
        return "ok";
    }

    /**
     * 判断名字的唯一性
     *
     * @param organizationId 组织ID
     * @param name     环境名
     * @return
     */
    @Permission(level = "organization",roles = {"projectOwner","projectMember","releaseAdmin"})
    @ApiOperation(value = "检查模板名是否可用")
    @GetMapping(value = "/environment/checkName")
    public ResponseEntity<String> checkName(@PathVariable Long organizationId, @RequestParam String name) {
        return Optional.ofNullable(environmentService.checkName(name))
                .map(target -> new ResponseEntity<>(target, HttpStatus.OK))
                .orElseThrow(() -> new HapException("error.environment.checkName"));
    }

    /**
     * 环境管理创建
     * @param organizationId 组织ID
     * @param environment 环境管理信息
     * @return 新建的环境管理
     */
    @Permission(level = "organization",roles = {"projectOwner","projectMember","releaseAdmin"})
    @ApiOperation(value = "环境管理创建")
    @RequestMapping(value = "/environment/create", method = RequestMethod.POST)
    public ResponseEntity<Environment> create(@PathVariable Long organizationId, @RequestBody Environment environment){
        return Optional.ofNullable(environmentService.create(organizationId, environment))
                .map(target -> new ResponseEntity<>(target, HttpStatus.OK))
                .orElseThrow(() -> new HapException("error.environment.create"));
    }

    /**
     * 环境管理修改
     * @param organizationId 组织ID
     * @param id 环境管理id
     * @param environment 环境管理信息
     * @return 环境管理修改
     */
    @Permission(level = "organization",roles = {"projectOwner","projectMember","releaseAdmin"})
    @ApiOperation(value = "环境管理修改")
    @RequestMapping(value = "/environment/update/{id}", method = RequestMethod.PUT)
    public ResponseEntity<Environment> update(@PathVariable Long organizationId,@PathVariable Long id, @RequestBody Environment environment){
        return Optional.ofNullable(environmentService.update(organizationId,id,environment))
                .map(target -> new ResponseEntity<>(target, HttpStatus.OK))
                .orElseThrow(() -> new HapException("error.environment.update"));
    }

    /**
     * 环境管理详情
     * @param organizationId 组织ID
     * @param id 环境管理id
     * @return 环境管理详情
     */
    @Permission(level = "organization",roles = {"projectOwner","projectMember","releaseAdmin"})
    @ApiOperation(value = "环境管理详情")
    @RequestMapping(value = "/environment/detail/{id}", method = RequestMethod.GET)
    public ResponseEntity<Environment> detail(@PathVariable Long organizationId,@PathVariable Long id){
        return Optional.ofNullable(environmentService.detail(organizationId, id))
                .map(target -> new ResponseEntity<>(target, HttpStatus.OK))
                .orElseThrow(() -> new HapException("error.environment.query"));
    }

    /**
     * 删除环境管理
     * @param organizationId 组织ID
     * @param id 环境管理id
     * @return 删除环境管理
     */
    @Permission(level = "organization",roles = {"projectOwner","projectMember","releaseAdmin"})
    @ApiOperation(value = "删除环境管理")
    @RequestMapping(value = "/environment/delete/{id}", method = RequestMethod.DELETE)
    public ResponseEntity<String> delete(@PathVariable Long organizationId,@PathVariable Long id){
        return Optional.ofNullable(environmentService.delete(organizationId, id))
                .map(target -> new ResponseEntity<>(target, HttpStatus.NO_CONTENT))
                .orElseThrow(() -> new HapException("error.environment.delete"));
    }

    /**
     * 分页查询环境管理信息
     *
     * @param organizationId 组织ID
     * @param page 当前页
     * @param size 当前页数量
     * @return ResponseEntity<Page<Environment>>
     *
     */
    @Permission(level = "organization",roles = {"projectOwner","projectMember","releaseAdmin"})
    @ApiOperation(value = "分页查询环境管理信息")
    @RequestMapping(value = "/environment/select", method = RequestMethod.GET)
    public ResponseEntity<Page<Environment>> select(@PathVariable Long organizationId,
                                                    @RequestParam(defaultValue = "0") Integer page,
                                                    @RequestParam(defaultValue = "5") Integer size){
        return Optional.ofNullable(environmentService.select(organizationId, page,size))
                .map(target -> new ResponseEntity<>(target, HttpStatus.OK))
                .orElseThrow(() -> new HapException("error.environment.query"));
    }

    /**
     * 查询全部环境管理信息
     *
     * @param organizationId 组织ID
     * @return ResponseEntity<List<Environment>>
     *
     */
    @Permission(level = "organization",roles = {"projectOwner","projectMember","releaseAdmin"})
    @ApiOperation(value = "查询全部环境管理信息")
    @RequestMapping(value = "/environment/selectAll", method = RequestMethod.GET)
    public ResponseEntity<List<Environment>> selectAll(@PathVariable Long organizationId){
        return Optional.ofNullable(environmentService.selectAll(organizationId))
                .map(target -> new ResponseEntity<>(target, HttpStatus.OK))
                .orElseThrow(() -> new HapException("error.environment.query"));
    }
}
