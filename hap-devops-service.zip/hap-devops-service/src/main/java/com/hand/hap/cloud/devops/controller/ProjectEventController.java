package com.hand.hap.cloud.devops.controller;

import com.hand.hap.cloud.devops.domain.project.ProjectEventMsg;
import com.hand.hap.cloud.devops.service.ProjectEventService;
import com.hand.hap.cloud.resource.exception.HapException;
import com.hand.hap.cloud.swagger.annotation.MenuLevel;
import com.hand.hap.cloud.swagger.annotation.Permission;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@MenuLevel("organization")
@RequestMapping(value = "/v1/test/devops")
public class ProjectEventController {

    @Autowired
    private ProjectEventService projectEventService;

    @Permission(level = "organization", roles = {"projectOwner"})
    @ApiOperation(value = "模拟项目变更事件发送!")
    @RequestMapping(value = "/organization/{organizationId}", method = RequestMethod.POST)
    public ResponseEntity project(@PathVariable Long organizationId,
                                  @RequestBody ProjectEventMsg projectEventMsg){
        return Optional.ofNullable(projectEventService.projectEventProc(organizationId,projectEventMsg))
                .map(target -> new ResponseEntity<>("success", HttpStatus.OK))
                .orElseThrow(() -> new HapException("error.project.operate"));
    }

}
