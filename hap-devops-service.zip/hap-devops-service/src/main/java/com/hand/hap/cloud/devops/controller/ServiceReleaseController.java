package com.hand.hap.cloud.devops.controller;

import com.hand.hap.cloud.devops.domain.serviceRelease.ServiceRelease;
import com.hand.hap.cloud.devops.service.ServiceReleaseService;
import com.hand.hap.cloud.resource.exception.HapException;
import com.hand.hap.cloud.swagger.annotation.Permission;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping(value = "/v1")
public class ServiceReleaseController {

    @Autowired
    private ServiceReleaseService serviceReleaseService;

    @Permission(level = "project", roles = {"releaseAdmin", "admin"})
    @ApiOperation(value = "发布服务")
    @RequestMapping(value = "/project/{projectId}/service/{serviceId}/release", method = RequestMethod.POST)
    public ResponseEntity<ServiceRelease> createDevopsService(@PathVariable Long projectId,
                                                              @PathVariable Long serviceId,
                                                              @RequestParam Long serviceVersionId,
                                                              @RequestParam Long environmentId) {
        return Optional.ofNullable(serviceReleaseService.create(serviceVersionId, environmentId))
                .map(target -> new ResponseEntity<>(target, HttpStatus.CREATED))
                .orElseThrow(() -> new HapException("error.service.release"));
    }
}
