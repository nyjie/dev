package com.hand.hap.cloud.devops.controller;

import com.hand.hap.cloud.devops.domain.service.ServiceType;
import com.hand.hap.cloud.devops.service.ServiceTypeService;
import com.hand.hap.cloud.resource.exception.HapException;
import com.hand.hap.cloud.swagger.annotation.Permission;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.Optional;

/**
 * Created with IntelliJ IDEA.
 * Description:
 * User: huangfengrun
 * Date: 2017-11-09
 */
@RestController
@RequestMapping(value = "/v1/devops")
public class ServiceTypeController {
    @Autowired
    private ServiceTypeService serviceTypeService;

    @Permission(permissionLogin = true)
    @ApiOperation(value = "查询服务类型列表")
    @RequestMapping(value = "serviceType/list", method = RequestMethod.GET)
    public List<ServiceType> selectAllServiceType(){
        return serviceTypeService.selectAll();
    }

    @Permission(permissionLogin = true)
    @ApiOperation(value = "创建服务类型")
    @RequestMapping(value = "serviceType/create", method = RequestMethod.POST)
    public ResponseEntity<ServiceType> createServiceType(@RequestParam @Valid String name, @RequestParam @Valid String path){
        ServiceType serviceType = new ServiceType();
        serviceType.setName(name);
        serviceType.setRepoPath(path);
        return Optional.ofNullable(serviceTypeService.create(serviceType))
                .map(result -> new ResponseEntity<>(result, HttpStatus.CREATED))
                .orElseThrow(() -> new HapException("error.service.type.create"));
    }

    @Permission(permissionLogin = true)
    @ApiOperation(value = "修改服务类型")
    @RequestMapping(value = "/serviceType/update", method = RequestMethod.PUT)
    public ResponseEntity<ServiceType> updateServiceType(@RequestBody ServiceType serviceType) {
        return Optional.ofNullable(serviceTypeService.modify(serviceType))
                .map(result -> new ResponseEntity<>(result, HttpStatus.CREATED))
                .orElseThrow(() -> new HapException("error.service.type.create"));
    }

    @Permission(permissionLogin = true)
    @ApiOperation(value = "删除服务类型")
    @RequestMapping(value = "/serviceType/{typeId}", method = RequestMethod.DELETE)
    public ResponseEntity deleteServiceType(@PathVariable @Valid Long typeId) {
        if (serviceTypeService.delete(typeId)){
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }else {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
