package com.hand.hap.cloud.devops.controller;

import com.hand.hap.cloud.devops.domain.serviceVersion.ServiceCiInfo;
import com.hand.hap.cloud.devops.domain.serviceVersion.ServiceVersion;
import com.hand.hap.cloud.devops.domain.serviceVersion.ServiceVersionReleaseEntity;
import com.hand.hap.cloud.devops.service.ServiceVersionService;
import com.hand.hap.cloud.resource.exception.HapException;
import com.hand.hap.cloud.swagger.annotation.Permission;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping(value = "/v1")
public class ServiceVersionController {

    @Autowired
    private ServiceVersionService serviceVersionService;

    @Permission(level = "project", roles = {"projectOwner", "projectMember"})
    @ApiOperation(value = "创建服务版本")
    @RequestMapping(value = "/project/{projectId}/service/{serviceId}/version", method = RequestMethod.POST)
    public ResponseEntity<ServiceVersion> createDevopsService(@PathVariable Long projectId,
                                                              @PathVariable Long serviceId,
                                                              @RequestBody ServiceCiInfo serviceCiInfo) {
        return Optional.ofNullable(serviceVersionService.create(serviceCiInfo, serviceId))
                .map(target -> new ResponseEntity<>(target, HttpStatus.CREATED))
                .orElseThrow(() -> new HapException("error.service.version.create"));
    }

    @Permission(level = "project", roles = {"projectOwner", "projectMember", "releaseAdmin"})
    @ApiOperation(value = "根据ServiceId分页查询ServiceVersion")
    @RequestMapping(value = "/project/{projectId}/service/{serviceId}/pageversion", method = RequestMethod.GET)
    public ResponseEntity<List<ServiceVersionReleaseEntity>> pageQueryWithServiceId(@PathVariable Long projectId,
                                                                                    @PathVariable Long serviceId,
                                                                                    @RequestParam Integer page,
                                                                                    @RequestParam Integer size) {
        ServiceVersion serviceVersion = new ServiceVersion();
        serviceVersion.setServiceId(serviceId);
        return Optional.ofNullable(serviceVersionService.queryByServiceId(serviceId, page, size))
                .map(result -> new ResponseEntity<>(result, HttpStatus.OK))
                .orElseThrow(() -> new HapException("error.service.version.query"));
    }
}
