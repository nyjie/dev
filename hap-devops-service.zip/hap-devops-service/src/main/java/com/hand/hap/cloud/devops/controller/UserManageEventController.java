package com.hand.hap.cloud.devops.controller;

import com.hand.hap.cloud.devops.domain.user.UserEventMsg;
import com.hand.hap.cloud.devops.service.UserManageEventService;
import com.hand.hap.cloud.swagger.annotation.MenuLevel;
import com.hand.hap.cloud.swagger.annotation.Permission;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * Created with IntelliJ IDEA.
 * Description:
 * UserProcMsg: huangfengrun
 * Date: 2017-11-07
 */

@RestController
@MenuLevel("organization")
@RequestMapping(value = "/v1/test/devops")
public class UserManageEventController {
    @Autowired
    private UserManageEventService userManageEventService;


//    @Permission(permissionLogin = true)
//    @ApiOperation(value = "模拟用户变更发送")
//    @RequestMapping(value = "/user", method = RequestMethod.POST)
//    public ResponseEntity proc(@RequestBody UserEventMsg userEventMsg) {
//        return userManageEventService.userManageEventProc(userEventMsg);
//    }

//    @Permission(level = "organization",roles = {"projectOwner"})
//    @ApiOperation(value = "模拟用户变更发送")
//    @RequestMapping(value = "/organization/{organizationId}/user", method = RequestMethod.POST)
//    public ResponseEntity proc(@PathVariable Long organizationId,@RequestBody UserEventMsg userEventMsg) {
//        return userManageEventService.userManageEventProc(userEventMsg);
//    }


}
