package com.hand.hap.cloud.devops.controller;

import com.hand.hap.cloud.devops.domain.usermember.UserMemberEventMsg;
import com.hand.hap.cloud.devops.service.UserMemberEventService;
import com.hand.hap.cloud.swagger.annotation.Permission;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/v1/test/devops")
public class UserMemberEventController {

    @Autowired
    private UserMemberEventService userMemberEventService;

//    @Permission(permissionLogin = true)
//    @ApiOperation(value = "模拟用户角色变更事件发送")
//    @RequestMapping(value = "/member", method = RequestMethod.POST)
//    public String  proc(@RequestBody UserMemberEventMsg userMemberEventMsg){
//        System.out.println(userMemberEventMsg);
//        return userMemberEventService.userMemberEventProc(userMemberEventMsg).toString();
//    }
}
