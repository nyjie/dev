package com.hand.hap.cloud.devops.domain.gitlab;

import java.util.Date;

/**
 * Created by qs on 2017/11/14.
 */
public class Owner {
    private Date createdAt;
    private Integer id;
    private String name;

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
