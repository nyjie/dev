package com.hand.hap.cloud.devops.domain.gitlab;

/**
 * Created by qs on 2017/11/14.
 */
public class Permissions {

    private ProjectAccess projectAccess;
    private ProjectAccess groupAccess;

    public Permissions() {
    }

    public ProjectAccess getProjectAccess() {
        return this.projectAccess;
    }

    public ProjectAccess getGroupAccess() {
        return this.groupAccess;
    }
}
