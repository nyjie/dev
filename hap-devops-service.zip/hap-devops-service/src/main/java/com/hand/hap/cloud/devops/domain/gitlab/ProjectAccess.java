package com.hand.hap.cloud.devops.domain.gitlab;

import com.hand.hap.cloud.devops.enums.AccessLevel;

/**
 * Created by qs on 2017/11/14.
 */
public class ProjectAccess {
    private AccessLevel accessLevel;
    private int notificationLevel;

    public ProjectAccess() {
    }

    public AccessLevel getAccessLevel() {
        return this.accessLevel;
    }

    public void setAccessLevel(AccessLevel accessLevel) {
        this.accessLevel = accessLevel;
    }

    public int getNotificationLevel() {
        return this.notificationLevel;
    }

    public void setNotificationLevel(int notificationLevel) {
        this.notificationLevel = notificationLevel;
    }
}
