package com.hand.hap.cloud.devops.domain.gitlab;

import com.hand.hap.cloud.mybatis.annotation.ModifyAudit;
import com.hand.hap.cloud.mybatis.domain.AuditDomain;

import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Created by zzy on 2017/11/14.
 */
@ModifyAudit
@Table(name = "project_attrs")
public class ProjectAttrs{

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getGitlabGroupId() {
        return gitlabGroupId;
    }

    public void setGitlabGroupId(Long gitlabGroupId) {
        this.gitlabGroupId = gitlabGroupId;
    }

    @Id
    @GeneratedValue
    private Long id;
    private Long gitlabGroupId;
}
