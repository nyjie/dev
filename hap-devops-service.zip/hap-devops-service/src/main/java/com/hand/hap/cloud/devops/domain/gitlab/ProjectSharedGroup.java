package com.hand.hap.cloud.devops.domain.gitlab;

import com.hand.hap.cloud.devops.enums.AccessLevel;

/**
 * Created by qs on 2017/11/14.
 */
public class ProjectSharedGroup {
    private Integer groupId;
    private String groupName;
    private AccessLevel groupAccessLevel;

    public ProjectSharedGroup() {
    }

    public int getGroupId() {
        return this.groupId.intValue();
    }

    public void setGroupId(int groupId) {
        this.groupId = Integer.valueOf(groupId);
    }

    public String getGroupName() {
        return this.groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public AccessLevel getGroupAccessLevel() {
        return this.groupAccessLevel;
    }

    public void setGroupAccessLevel(AccessLevel accessLevel) {
        this.groupAccessLevel = accessLevel;
    }
}

