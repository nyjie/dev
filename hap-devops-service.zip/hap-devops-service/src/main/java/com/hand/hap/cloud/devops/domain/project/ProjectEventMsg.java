package com.hand.hap.cloud.devops.domain.project;

public class ProjectEventMsg {
    private Long id;    //Hapcloud的项目Id
    private String code;    //Hapcloud的项目编码【对应Gitlab的组名】
    private String name;    //Hapcloud的项目名称
    private String operationType;   //操作类型

    public String getOperationType() {
        return operationType;
    }

    public void setOperationType(String operationType) {
        this.operationType = operationType;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }
}
