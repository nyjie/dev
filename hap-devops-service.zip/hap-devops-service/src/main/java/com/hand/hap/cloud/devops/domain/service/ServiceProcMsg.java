package com.hand.hap.cloud.devops.domain.service;

public class ServiceProcMsg {

    private String serviceName;
    private String serviceCode;
    private String serviceTypeName;
    private String serviceRepoPath;
    private String projectCode;

    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    public String getServiceCode() {
        return serviceCode;
    }

    public void setServiceCode(String serviceCode) {
        this.serviceCode = serviceCode;
    }

    public String getServiceTypeName() {
        return serviceTypeName;
    }

    public void setServiceTypeName(String serviceTypeName) {
        this.serviceTypeName = serviceTypeName;
    }

    public String getServiceRepoPath() {
        return serviceRepoPath;
    }

    public void setServiceRepoPath(String serviceRepoPath) {
        this.serviceRepoPath = serviceRepoPath;
    }

    public String getProjectCode() {
        return projectCode;
    }

    public void setProjectCode(String projectCode) {
        this.projectCode = projectCode;
    }
}
