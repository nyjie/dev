package com.hand.hap.cloud.devops.domain.serviceRelease;

import com.hand.hap.cloud.mybatis.annotation.ModifyAudit;
import com.hand.hap.cloud.mybatis.annotation.VersionAudit;

import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@ModifyAudit
@VersionAudit
@Table(name = "service_release")
public class ServiceRelease {

    @Id
    @GeneratedValue
    private Long id;

    @NotNull
    private Long serviceVersionId;

    @NotNull
    private Long environmentId;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getServiceVersionId() {
        return serviceVersionId;
    }

    public void setServiceVersionId(Long serviceVersionId) {
        this.serviceVersionId = serviceVersionId;
    }

    public Long getEnvironmentId() {
        return environmentId;
    }

    public void setEnvironmentId(Long environmentId) {
        this.environmentId = environmentId;
    }
}
