package com.hand.hap.cloud.devops.domain.serviceVersion;

public class Requests {
    private String memory;

    public String getMemory() {
        return memory;
    }

    public void setMemory(String memory) {
        this.memory = memory;
    }
}
