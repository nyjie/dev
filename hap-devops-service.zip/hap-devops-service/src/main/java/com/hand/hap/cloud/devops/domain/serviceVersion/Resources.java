package com.hand.hap.cloud.devops.domain.serviceVersion;

public class Resources {
    private Limits limits;

    private Requests requests;

    public Limits getLimits() {
        return limits;
    }

    public void setLimits(Limits limits) {
        this.limits = limits;
    }

    public Requests getRequests() {
        return requests;
    }

    public void setRequests(Requests requests) {
        this.requests = requests;
    }
}
