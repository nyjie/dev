package com.hand.hap.cloud.devops.domain.serviceVersion;

import java.util.List;

public class ServiceVersionReleaseEntity {
    private ServiceVersion serviceVersion;

    private List<String> envName;

    public ServiceVersion getServiceVersion() {
        return serviceVersion;
    }

    public void setServiceVersion(ServiceVersion serviceVersion) {
        this.serviceVersion = serviceVersion;
    }

    public List<String> getEnvName() {
        return envName;
    }

    public void setEnvName(List<String> envName) {
        this.envName = envName;
    }
}
