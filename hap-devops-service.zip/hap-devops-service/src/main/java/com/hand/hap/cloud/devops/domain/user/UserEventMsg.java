package com.hand.hap.cloud.devops.domain.user;

/**
 * Created with IntelliJ IDEA.
 * Description:
 * UserProcMsg: huangfengrun
 * Date: 2017-11-07
 */
public class UserEventMsg {
    private String username;    //Hapcloud用户名
    private String email;   //Hapcloud用户邮箱
    private String operationType;   //Hapcloud用户操作类型
    private String id;  //Hapcloud用户Id
    private Long organizationId;    //Hapcloud用户所属组织Id
    private String uuid;
    public Long getOrganizationId() {
        return organizationId;
    }

    public void setOrganizationId(Long organizationId) {
        this.organizationId = organizationId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getOperationType() {
        return operationType;
    }

    public void setOperationType(String operationType) {
        this.operationType = operationType;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }


    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

}
