package com.hand.hap.cloud.devops.domain.usermember;

public enum UserMember {
    OWNER(50),MASTER(40),DEVELOPER(30),REPORTER(20),GUEST(10);

    private int accessLevel;

    private UserMember(int accessLevel){
        this.accessLevel = accessLevel;
    }
}
