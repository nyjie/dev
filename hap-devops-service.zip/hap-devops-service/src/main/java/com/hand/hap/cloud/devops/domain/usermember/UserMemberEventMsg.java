package com.hand.hap.cloud.devops.domain.usermember;

import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.List;

public class UserMemberEventMsg {

    private String username;    //被更改角色的用户的用户名

    private Long projectId; //项目Id

    private List<String> usermember;    //权限列表

    private String projectCreator;  //项目创建者

    private String uuid;

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }


    public String getProjectCreator() {
        return projectCreator;
    }

    public void setProjectCreator(String projectCreator) {
        this.projectCreator = projectCreator;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Long getProjectId() {
        return projectId;
    }

    public void setProjectId(Long projectId) {
        this.projectId = projectId;
    }

    public List<String> getUsermember() {
        return usermember;
    }

    public void setUsermember(List<String> usermember) {
        this.usermember = usermember;
    }
}
