package com.hand.hap.cloud.devops.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by qs on 2017/11/14.
 */
public enum AccessLevel {
    NONE(0),
    GUEST(10),
    REPORTER(20),
    DEVELOPER(30),
    MASTER(40),
    OWNER(50);

    public final Integer value;
    private static Map<Integer, AccessLevel> valuesMap = new HashMap(6);

    private AccessLevel(int value) {
        this.value = Integer.valueOf(value);
    }

    @JsonCreator
    public static AccessLevel forValue(Integer value) {
        return (AccessLevel)valuesMap.get(value);
    }

    @JsonValue
    public Integer toValue() {
        return this.value;
    }

    public String toString() {
        return this.value.toString();
    }

    static {
        AccessLevel[] var0 = values();
        int var1 = var0.length;

        for(int var2 = 0; var2 < var1; ++var2) {
            AccessLevel accessLevel = var0[var2];
            valuesMap.put(accessLevel.value, accessLevel);
        }

    }
}
