package com.hand.hap.cloud.devops.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

/**
 * Created by qs on 2017/11/14.
 */
public enum Visibility {
    PUBLIC,
    PRIVATE,
    INTERNAL;

    private Visibility() {
    }
}

