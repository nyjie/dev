package com.hand.hap.cloud.devops.mapper;

import com.hand.hap.cloud.devops.domain.service.DevopsService;
import com.hand.hap.cloud.mybatis.common.BaseMapper;

public interface DevopsServiceMapper extends BaseMapper<DevopsService> {
}
