package com.hand.hap.cloud.devops.mapper;

import com.hand.hap.cloud.devops.domain.environment.Environment;
import com.hand.hap.cloud.mybatis.common.BaseMapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * Created by qs on 2017/11/15.
 */
public interface EnvironmentMapper extends BaseMapper<Environment> {

    List<Environment> enviromentSelect(@Param("organizationId") Long organizationId);
}
