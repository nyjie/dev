package com.hand.hap.cloud.devops.mapper;

import com.hand.hap.cloud.devops.domain.gitlab.ProjectAttrs;
import com.hand.hap.cloud.devops.domain.service.DevopsService;
import com.hand.hap.cloud.mybatis.common.BaseMapper;

/**
 * Created by zzy on 2017/11/14.
 */
public interface ProjectEventMapper extends BaseMapper<ProjectAttrs> {
}
