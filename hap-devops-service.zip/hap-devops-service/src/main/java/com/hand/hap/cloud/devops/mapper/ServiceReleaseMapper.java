package com.hand.hap.cloud.devops.mapper;

import com.hand.hap.cloud.devops.domain.serviceRelease.ServiceRelease;
import com.hand.hap.cloud.mybatis.common.BaseMapper;

import java.util.List;

public interface ServiceReleaseMapper extends BaseMapper<ServiceRelease> {
    List<String> findEnvByServiceVersionId(Long serviceVersionId);
}
