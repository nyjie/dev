package com.hand.hap.cloud.devops.mapper;

import com.hand.hap.cloud.devops.domain.service.ServiceType;
import com.hand.hap.cloud.mybatis.common.BaseMapper;

/**
 * Created with IntelliJ IDEA.
 * Description:
 * User: huangfengrun
 * Date: 2017-11-08
 */

public interface ServiceTypeMapper extends BaseMapper<ServiceType> {
}
