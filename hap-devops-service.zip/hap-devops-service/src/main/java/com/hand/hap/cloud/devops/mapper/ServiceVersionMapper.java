package com.hand.hap.cloud.devops.mapper;

import com.hand.hap.cloud.devops.domain.serviceVersion.ServiceVersion;
import com.hand.hap.cloud.mybatis.common.BaseMapper;

public interface ServiceVersionMapper extends BaseMapper<ServiceVersion> {
}
