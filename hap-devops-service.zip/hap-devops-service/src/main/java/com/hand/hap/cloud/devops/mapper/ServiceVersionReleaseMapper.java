package com.hand.hap.cloud.devops.mapper;

import com.hand.hap.cloud.devops.domain.serviceVersion.ServiceVersionRelease;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface ServiceVersionReleaseMapper {
    List<ServiceVersionRelease> findServiceVersionRelease(@Param("serviceId") Long serviceId);
}
