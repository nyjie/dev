package com.hand.hap.cloud.devops.service;

import com.hand.hap.cloud.devops.domain.service.DevopsService;
import com.hand.hap.cloud.mybatis.pagehelper.domain.Page;
import com.hand.hap.cloud.mybatis.service.BaseService;

import java.util.List;

public interface DevopsServiceService extends BaseService<DevopsService>{

    DevopsService create(Long organizationId, Long projectId, DevopsService devopsService);

    DevopsService update(Long serviceId, String code, String name);

    boolean delete(Long projectId, Long serviceId);

    List<DevopsService> queryProjectService(Long projectId,Long organizationId);

    Boolean selectDevopsServiceParamCode(Long projectId,String code);

    Boolean selectDevopsServiceParamName(Long projectId,String name);

    List<DevopsService> selectDevopsService(Long projectId,Long organizationId,Long serviceId);

    Page<DevopsService> pageDevopsService(Long projectId, Long organizationId,Integer page, Integer size);
}
