package com.hand.hap.cloud.devops.service;

import com.hand.hap.cloud.devops.domain.environment.Environment;
import com.hand.hap.cloud.mybatis.pagehelper.domain.Page;
import com.hand.hap.cloud.mybatis.service.BaseService;

import java.util.List;

/**
 * Created by qs on 2017/11/15.
 */
public interface EnvironmentService extends BaseService<Environment> {

    String checkName(String name);

    Environment create(Long organizationId,Environment environment);

    Environment update(Long organizationId,Long id,Environment environment);

    Environment detail(Long organizationId,Long id);

    Page<Environment>  select(Long organizationId,Integer page,Integer size);

    List<Environment> selectAll(Long organizationId);

    String delete(Long organizationId,Long id);
}
