package com.hand.hap.cloud.devops.service;

import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.api.errors.GitAPIException;

import java.io.File;
import java.io.IOException;
import java.util.List;

/**
 * Created by qs on 2017/11/7.
 */
public interface GitService {

   Git clone(String name, String remoteUrl);

   File exists(String name);

   String getWorkingDirectory(String name);

   void deleteWorkingDirectory(String name);

   Git getGitByOpen(File file) throws IOException;

   List<String> getTags(Git git) throws GitAPIException;

   void deleteLocalTags(Git git);

   void checkoutTag(Git git, String tag);

   String readFile(String name, String fileName);

   void gitCreateBranch(Git git, boolean flag);

   void gitPull(Git git);
}
