package com.hand.hap.cloud.devops.service;

import com.hand.hap.cloud.devops.domain.project.ProjectEventMsg;
import org.springframework.http.ResponseEntity;

public interface ProjectEventService {
    ResponseEntity projectEventProc(Long organizationId,ProjectEventMsg projectEventMsg);
}
