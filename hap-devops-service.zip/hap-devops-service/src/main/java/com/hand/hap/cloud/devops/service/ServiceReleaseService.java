package com.hand.hap.cloud.devops.service;

import com.hand.hap.cloud.devops.domain.serviceRelease.ServiceRelease;
import com.hand.hap.cloud.mybatis.service.BaseService;

public interface ServiceReleaseService extends BaseService<ServiceRelease> {
    ServiceRelease create(Long serviceVersionId, Long environmentId);
}
