package com.hand.hap.cloud.devops.service;

import com.hand.hap.cloud.devops.domain.service.ServiceType;
import com.hand.hap.cloud.mybatis.service.BaseService;

/**
 * Created with IntelliJ IDEA.
 * Description:
 * User: huangfengrun
 * Date: 2017-11-08
 */

public interface ServiceTypeService extends BaseService<ServiceType> {
    ServiceType create(ServiceType serviceType);

    ServiceType modify(ServiceType serviceType);

    boolean delete(Long id);
}
