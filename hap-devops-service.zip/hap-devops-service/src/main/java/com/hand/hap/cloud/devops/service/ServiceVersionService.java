package com.hand.hap.cloud.devops.service;

import com.hand.hap.cloud.devops.domain.serviceVersion.ServiceCiInfo;
import com.hand.hap.cloud.devops.domain.serviceVersion.ServiceVersion;
import com.hand.hap.cloud.devops.domain.serviceVersion.ServiceVersionReleaseEntity;
import com.hand.hap.cloud.mybatis.service.BaseService;

import java.util.List;

public interface ServiceVersionService extends BaseService<ServiceVersion> {

    ServiceVersion create(ServiceCiInfo serviceCiInfo, Long serviceId);

    List<ServiceVersionReleaseEntity> queryByServiceId(Long serviceId, int page, int size);
}
