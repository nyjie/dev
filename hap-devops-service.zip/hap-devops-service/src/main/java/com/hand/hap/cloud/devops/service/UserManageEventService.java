package com.hand.hap.cloud.devops.service;

import com.hand.hap.cloud.devops.domain.user.UserEventMsg;
import org.springframework.http.ResponseEntity;

/**
 * Created by huangfengrun on 2017/11/7.
 */
public interface UserManageEventService {
    ResponseEntity userManageEventProc(String msg);
}
