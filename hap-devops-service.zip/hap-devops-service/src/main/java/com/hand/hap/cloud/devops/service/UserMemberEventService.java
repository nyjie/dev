package com.hand.hap.cloud.devops.service;

import com.hand.hap.cloud.devops.domain.usermember.UserMemberEventMsg;
import org.springframework.http.ResponseEntity;


public interface UserMemberEventService {
    ResponseEntity userMemberEventProc(String msg);
}
