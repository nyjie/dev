package com.hand.hap.cloud.devops.service.impl;

import com.hand.hap.cloud.devops.client.HapCloudUserFeign;
import com.hand.hap.cloud.devops.client.ServiceFeign;
import com.hand.hap.cloud.devops.domain.gitlab.Project;
import com.hand.hap.cloud.devops.domain.gitlab.ProjectAttrs;
import com.hand.hap.cloud.devops.domain.service.DevopsService;
import com.hand.hap.cloud.devops.domain.service.HapcloudProject;
import com.hand.hap.cloud.devops.domain.service.ServiceProcMsg;
import com.hand.hap.cloud.devops.domain.service.ServiceType;
import com.hand.hap.cloud.devops.mapper.DevopsServiceMapper;
import com.hand.hap.cloud.devops.mapper.ProjectEventMapper;
import com.hand.hap.cloud.devops.mapper.ServiceTypeMapper;
import com.hand.hap.cloud.devops.service.DevopsServiceService;
import com.hand.hap.cloud.devops.service.GitService;
import com.hand.hap.cloud.devops.utils.TypeUtils;
import com.hand.hap.cloud.mybatis.pagehelper.domain.Page;
import com.hand.hap.cloud.mybatis.service.BaseServiceImpl;
import com.hand.hap.cloud.resource.exception.HapException;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.api.errors.GitAPIException;
import org.eclipse.jgit.transport.CredentialsProvider;
import org.eclipse.jgit.transport.UsernamePasswordCredentialsProvider;
import org.jtwig.JtwigModel;
import org.jtwig.JtwigTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

@Service
public class DevopsServiceServiceImpl extends BaseServiceImpl<DevopsService> implements DevopsServiceService{

    private static final Logger logger = LoggerFactory.getLogger(DevopsServiceServiceImpl.class);

    @Autowired
    private ServiceFeign serviceFeign;
    @Autowired
    private DevopsServiceMapper devopsServiceMapper;
    @Autowired
    private ServiceTypeMapper serviceTypeMapper;
    @Autowired
    private HapCloudUserFeign hapCloudUserFeign;
    @Autowired
    private GitService gitService;
    @Autowired
    private ProjectEventMapper projectEventMapper;

    @Value("${gitlab.url}")
    private String gitlabUrl;

    @Value("${data.apiGateWay}")
    private String apiGateWay;

    @Value("${data.registryAddress}")
    private String registryAddress;

    @Value("${data.registryUsername}")
    private String registryUsername;

    @Value("${data.registryPassword}")
    private String registryPassword;

    @Override
    public DevopsService create(Long organizationId, Long projectId, DevopsService devopsService) {
        DevopsService devopsServiceTmp = new DevopsService();
        devopsServiceTmp.setCode(devopsService.getCode());
        devopsServiceTmp.setProjectId(devopsService.getProjectId());
        if (!devopsServiceMapper.select(devopsServiceTmp).isEmpty()){
            throw new HapException("error.service.exist");
        }
        HapcloudProject hapcloudProject = hapCloudUserFeign.queryHapcloudProject(organizationId,projectId).getBody();
        if(hapcloudProject == null){
            throw new HapException("error.select.hapcloud.project");
        }
        ServiceType serviceType = serviceTypeMapper.selectByPrimaryKey(devopsService.getServiceTypeId());
        if(serviceType == null){
            throw new HapException("error.select.service.type");
        }

        ServiceProcMsg serviceProcMsg = new ServiceProcMsg();
        serviceProcMsg.setProjectCode(hapcloudProject.getCode());
        serviceProcMsg.setServiceRepoPath(serviceType.getRepoPath());
        serviceProcMsg.setServiceName(devopsService.getName());
        serviceProcMsg.setServiceTypeName(serviceType.getName());
        serviceProcMsg.setServiceCode(devopsService.getCode());

        Project project = addService(projectId,serviceProcMsg);
        devopsService.setGitlabProjectId(TypeUtils.objToLong(project.getId()));
        if(devopsServiceMapper.insert(devopsService) != 1){
            throw new HapException("error.devopsService.select");
        }
        DevopsService devops = selectByPrimaryKey(devopsService);
        devops.setRepoUrl(project.getHttpUrlToRepo());
        //增加发布版本所需的ci环境变量
        serviceFeign.addVariable(project.getId(),"SERVICE_ID", TypeUtils.objToString(devops.getId()), false);
        return devops;
    }

    @Override
    public DevopsService update(Long serviceId, String code, String name) {
        DevopsService devopsServiceCur = devopsServiceMapper.selectByPrimaryKey(serviceId);
        devopsServiceCur.setName(name);
        Project project = serviceFeign.updateProject(devopsServiceCur.getGitlabProjectId().intValue(),code).getBody();
        devopsServiceCur.setCode(code);
        devopsServiceMapper.updateByPrimaryKey(devopsServiceCur);
        DevopsService devopsService = devopsServiceMapper.selectByPrimaryKey(devopsServiceCur.getId());
        devopsService.setRepoUrl(project.getHttpUrlToRepo());
        return devopsService;
    }

    @Override
    public boolean delete(Long projectId,Long serviceId) {
        DevopsService devopsService = devopsServiceMapper.selectByPrimaryKey(serviceId);
        if (serviceFeign.deleteProject(devopsService.getGitlabProjectId().intValue()).getStatusCode() == HttpStatus.NO_CONTENT){
            devopsServiceMapper.deleteByPrimaryKey(serviceId);
            return true;
        }else {
            throw new HapException("error.gitlab.service.delete");
        }
    }

    public String getGitUrl(Long organizationId,Long projectId,String code){
        HapcloudProject hapcloudProject = hapCloudUserFeign.queryHapcloudProject(organizationId,projectId).getBody();
        String projectCode = "";
        if (hapcloudProject != null){
            projectCode = hapcloudProject.getCode();
        }
        String url = gitlabUrl+"/" + projectCode+"/" + code+".git";
        return url;
    }

    @Override
    public List<DevopsService> queryProjectService(Long projectId,Long organizationId){
        DevopsService devopsService = new DevopsService();
        devopsService.setProjectId(projectId);
        List<DevopsService> devopsServices = select(devopsService);
        for (DevopsService devopsService1 : devopsServices){
            devopsService1.setRepoUrl(getGitUrl(organizationId,projectId,devopsService1.getCode()));
        }
        return devopsServices;
    }

    @Override
    public Boolean selectDevopsServiceParamCode(Long projectId,String code){
        DevopsService devopsService = new DevopsService();
        devopsService.setProjectId(projectId);
        if (code != null)
            devopsService.setCode(code);
        return select(devopsService).isEmpty();
    }

    @Override
    public Boolean selectDevopsServiceParamName(Long projectId,String name){
        DevopsService devopsService = new DevopsService();
        devopsService.setProjectId(projectId);
        if (name != null)
            devopsService.setName(name);
        return select(devopsService).isEmpty();
    }

    @Override
    public List<DevopsService> selectDevopsService(Long projectId,Long organizationId,Long serviceId){
        DevopsService devopsService = new DevopsService();
        devopsService.setId(serviceId);
        devopsService.setProjectId(projectId);
        List<DevopsService> devopsServices = select(devopsService);
        for (DevopsService devopsService1:devopsServices){
            devopsService1.setRepoUrl(getGitUrl(organizationId,projectId,devopsService1.getCode()));
        }
        return devopsServices;
    }

    @Override
    public Page<DevopsService> pageDevopsService(Long projectId,Long organizationId, Integer page, Integer size){
        DevopsService devopsService = new DevopsService();
        devopsService.setProjectId(projectId);
        Page<DevopsService> devopsServices = page(devopsService, page, size);
        for (DevopsService devopsService1:devopsServices){
            devopsService1.setRepoUrl(getGitUrl(organizationId,projectId,devopsService1.getCode()));
        }
        return devopsServices;
    }

    private Project addService(Long projectId,ServiceProcMsg serviceProcMsg) {
        if(!isEmpty(serviceProcMsg)){
            throw new HapException("required is empty");
        }
        String name = serviceProcMsg.getServiceTypeName()+System.currentTimeMillis();
        String remoteUrl = serviceProcMsg.getServiceRepoPath();

        //拉取模板
        Git git = gitService.clone(name,remoteUrl);
        //删除.git文件夹
//        gitService.deleteWorkingDirectory(name+"/"+".git");

        //新建代码库
        ProjectAttrs gitlabProject = new ProjectAttrs();
        gitlabProject.setId(projectId);
        ProjectAttrs p = projectEventMapper.selectByPrimaryKey(gitlabProject);
        if(p == null){
            throw new HapException("gitlab groupId not found");
        }

        ResponseEntity<Project> projectResponseEntity = serviceFeign.createProject(TypeUtils.objToInteger(p.getGitlabGroupId()),serviceProcMsg.getServiceCode());
        if (projectResponseEntity.getStatusCode() != HttpStatus.OK){
            //删除模板
            gitService.deleteWorkingDirectory(name);
            throw new HapException("error.create.project");
        }
        Project project = projectResponseEntity.getBody();
        if(project == null){
            //删除模板
            gitService.deleteWorkingDirectory(name);
            throw new HapException("create gitlab project is error");
        }

        //渲染模板里面的参数
        try{
            if("Micro Service".equals(serviceProcMsg.getServiceTypeName())){
                renderTemplate(name,"pom.xml",serviceProcMsg,project,"Micro Service",projectId);
                renderTemplate(name,"src/main/resources/bootstrap.yml",serviceProcMsg,project,"Micro Service",projectId);
                renderTemplate(name,".gitlab-ci.yml",serviceProcMsg,project,"Micro Service",projectId);
                renderTemplate(name,"deploy.yml",serviceProcMsg,project,"Micro Service",projectId);
            }else if("Web Front-end".equals(serviceProcMsg.getServiceTypeName())){
             //   renderTemplate(name,".gitlab-ci.yml",serviceProcMsg,project,"Web Front-end",projectId);
                renderTemplate(name,"deploy.yml",serviceProcMsg,project,"Web Front-end",projectId);
            }
        }catch (Exception e){
            //删除gitlab新建的项目
            deleteGitlabProject(project.getId());
            //删除模板
            gitService.deleteWorkingDirectory(name);
            throw new HapException(e.getMessage());
        }

        //提交代码
        logger.info(project.getHttpUrlToRepo());
        //将渲染的模板上传新建的代码库
//        Git git = null;
        try {
//            git = Git.init().setDirectory(new File(gitService.getWorkingDirectory(name))).call();
            git.add().addFilepattern(".").call();
            git.commit().setMessage("Render Variables[skip ci]").call();
            CredentialsProvider cp = new UsernamePasswordCredentialsProvider("root", "handhand");
            git.push().setRemote(project.getHttpUrlToRepo()).setCredentialsProvider(cp).call();
        }catch (GitAPIException e){
            //删除gitlab新建的项目
            deleteGitlabProject(project.getId());
            throw new HapException("git push origin master is error: "+e.getMessage());
        }finally {
            //删除模板
            gitService.deleteWorkingDirectory(name);
            if(git != null){
                git.close();
            }
        }

        serviceFeign.addVariable(project.getId(),"PROJECT_ID", TypeUtils.objToString(projectId), false);
        serviceFeign.addVariable(project.getId(),"API_GATEWAY",apiGateWay , false);
        serviceFeign.addVariable(project.getId(),"USER_NAME","admin" , false);
        serviceFeign.addVariable(project.getId(),"USER_PASS","admin" , false);
        serviceFeign.addVariable(project.getId(),"REGISTRY_ADDRESS",registryAddress , false);
        if(!StringUtils.isEmpty(registryUsername)) {
            serviceFeign.addVariable(project.getId(), "REGISTRY_USER", registryUsername, false);
        }
        if(!StringUtils.isEmpty(registryPassword)) {
            serviceFeign.addVariable(project.getId(), "REGISTRY_PWD", registryPassword, false);
        }
        serviceFeign.addVariable(project.getId(),"PORJECT_NAME",serviceProcMsg.getProjectCode() , false);
        serviceFeign.addVariable(project.getId(),"APPLICATION_NAME",serviceProcMsg.getServiceCode() , false);

        return project;
    }

    public boolean isEmpty(ServiceProcMsg serviceProcMsg){
        if((StringUtils.isEmpty(serviceProcMsg.getServiceTypeName())) ||
                (StringUtils.isEmpty(serviceProcMsg.getServiceRepoPath()))
                || (StringUtils.isEmpty(serviceProcMsg.getServiceTypeName()))
                || (StringUtils.isEmpty(serviceProcMsg.getServiceCode()))){
            return false;
        }
        return true;
    }

    private void renderModel(ServiceProcMsg serviceProcMsg,JtwigModel jtwigModel){
        jtwigModel.with("REGISTRY_ADDRESS",registryAddress);
        jtwigModel.with("MAVEN_GROUP_ID", serviceProcMsg.getProjectCode());
        jtwigModel.with("MAVEN_ARTIFACT_ID", serviceProcMsg.getServiceCode());
        jtwigModel.with("APPLICATION_NAME", serviceProcMsg.getServiceCode());
        jtwigModel.with("PORJECT_NAME", serviceProcMsg.getProjectCode());
    }

    private void renderTemplate(String name,String relativePaths,ServiceProcMsg serviceProcMsg,Project project,String serviceType,Long projectId){
        String render = "";
        File f = new File(gitService.getWorkingDirectory(name)+ "/" + relativePaths);
        try {
            render = FileUtils.readFileToString(f, "UTF-8");
        } catch (IOException e) {
            throw new HapException("read file is error: "+f);
        }

        //将所有参数加入模板
        JtwigTemplate jtwigTemplate = JtwigTemplate.inlineTemplate(render);
        JtwigModel jtwigModel = JtwigModel.newModel();
        List<String> list = Arrays.asList("pom.xml","src/main/resources/bootstrap.yml",".gitlab-ci.yml","deploy.yml");
        if(serviceType == "Micro Service") {
            if(list.contains(relativePaths)){
                renderModel(serviceProcMsg,jtwigModel);
            }
        }
        if(serviceType == "Web Front-end"){
            if (list.contains(relativePaths)) {
                renderModel(serviceProcMsg,jtwigModel);
            }
        }

        String renderPom = jtwigTemplate.render(jtwigModel);
        File pomFile = new File(gitService.getWorkingDirectory(name)+ "/" + relativePaths);
        if(pomFile.exists()){
            pomFile.delete();
        }
        try {
            pomFile.createNewFile();
            write(pomFile.getPath(),renderPom);
        }catch (IOException e){
            throw new HapException("write file is error: "+e.getMessage());
        }
    }

    /**
     * 将内容回写到文件中
     * @param filePath
     * @param content
     */
    public void write(String filePath, String content) {
        BufferedWriter bw = null;
        try {
            // 根据文件路径创建缓冲输出流
            bw = new BufferedWriter(new FileWriter(filePath));
            // 将内容写入文件中
            bw.write(content);
        } catch (Exception e) {
            throw new HapException(filePath+" writer file is error: "+e.getMessage());
        } finally {
            // 关闭流
            if (bw != null) {
                try {
                    bw.close();
                } catch (IOException e) {
                    logger.debug(e.getMessage());
                }
            }
        }
    }

    public void deleteGitlabProject(Integer id){
        //删除gitlab新建的项目
        serviceFeign.deleteProject(id);
    }
}
