package com.hand.hap.cloud.devops.service.impl;

import com.hand.hap.cloud.devops.domain.environment.Environment;
import com.hand.hap.cloud.devops.domain.serviceRelease.ServiceRelease;
import com.hand.hap.cloud.devops.mapper.EnvironmentMapper;
import com.hand.hap.cloud.devops.mapper.ServiceReleaseMapper;
import com.hand.hap.cloud.devops.service.EnvironmentService;
import com.hand.hap.cloud.devops.utils.Ping;
import com.hand.hap.cloud.mybatis.pagehelper.PageHelper;
import com.hand.hap.cloud.mybatis.pagehelper.domain.Page;
import com.hand.hap.cloud.mybatis.service.BaseServiceImpl;
import com.hand.hap.cloud.resource.exception.HapException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

/**
 * Created by qs on 2017/11/15.
 */
@Service
public class EnvironmentServiceImpl extends BaseServiceImpl<Environment> implements EnvironmentService {

    private static final Logger logger = LoggerFactory.getLogger(EnvironmentServiceImpl.class);

    @Autowired
    private EnvironmentMapper environmentMapper;
    @Autowired
    private ServiceReleaseMapper serviceReleaseMapper;
    @Value("${data.apiGateWay}")
    private String apiGateWay;

    @Override
    public String checkName(String name) {
        if(name == null || name.isEmpty()) {
            throw new HapException("error.name.empty");
        }
        Environment environment = new Environment();
        environment.setName(name);
        if(select(environment).size() != 0){
            throw new HapException("error.environment.name.existed");
        }
        return "success";
    }

    @Override
    public Environment create(Long organizationId, Environment environment) {
        isOperation(environment);
        if(!organizationId.equals(environment.getOrganizationId())){
            throw new HapException("error.organizationId.equal");
        }
        if (insert(environment) != 1) {
            throw new HapException("error.environment.insert");
        }
        return selectByPrimaryKey(environment.getId());
    }

    @Override
    public Environment update(Long organizationId,Long id, Environment environment) {
        isOperation(environment);
        Environment env = selectByPrimaryKey(id);
        if(!organizationId.equals(env.getOrganizationId())){
            throw new HapException("error.organizationId.equal");
        }
        environment.setId(id);
        environment.setOrganizationId(organizationId);
        if (updateByPrimaryKeySelective(environment) != 1) {
            throw new HapException("error.environment.update");
        }
        return selectByPrimaryKey(environment.getId());
    }

    @Override
    public Environment detail(Long organizationId, Long id) {
        Environment environment = selectByPrimaryKey(id);
        if(!organizationId.equals(environment.getOrganizationId())){
            throw new HapException("error.organizationId.equal");
        }
        return environment;
    }

    @Override
    public Page<Environment> select(Long organizationId, Integer page, Integer size) {
        return PageHelper.doPage(page, size, () -> environmentMapper.enviromentSelect(organizationId));
    }

    @Override
    public List<Environment> selectAll(Long organizationId){
        return environmentMapper.enviromentSelect(organizationId);
    }

    @Override
    public String delete(Long organizationId, Long id) {
        Environment environment = selectByPrimaryKey(id);
        if(!organizationId.equals(environment.getOrganizationId())){
            throw new HapException("error.organizationId.equal");
        }
        ServiceRelease serviceRelease = new ServiceRelease();
        serviceRelease.setEnvironmentId(environment.getId());
        if(serviceReleaseMapper.select(serviceRelease).size() > 0){
            throw new HapException("Service release has existed ,cannot be deleted");
        }

        if(delete(environment) != 1){
            throw new HapException("error.environment.delete");
        }
        return "success";
    }

    public void isOperation( Environment environment){
        URL url = null;
        try {
            url = new URL(environment.getUrl());
        }catch (MalformedURLException e){
            throw new HapException("url is error: "+e.getMessage());
        }
        //IP是否能ping通
//        if(!Ping.ping(String.valueOf(url.getHost()),2,5000)){
//            throw new HapException("error.url.ping");
//        }

        //能否有权限访问
        RestTemplate restTemplate = new RestTemplate();
        //向restTemplate中添加自定义的拦截器
        restTemplate.getInterceptors().add(new OAuthAuthorizationInterceptor(environment.getToken()));

        int statusCode = 0;
        try {
            statusCode = restTemplate.getForEntity(apiGateWay+"/uaa/v1/users/querySelf", null).getStatusCodeValue();
        }catch (Exception e){
            logger.debug(e.getMessage());
        }
        if(statusCode != 200){
            throw new HapException("error.token.get");
        }
    }

    class OAuthAuthorizationInterceptor implements ClientHttpRequestInterceptor {
        private final String token;

        private OAuthAuthorizationInterceptor(String token) {
            this.token = token;
        }

        public ClientHttpResponse intercept(HttpRequest request, byte[] body, ClientHttpRequestExecution execution) throws IOException {
            request.getHeaders().add("Authorization", "Bearer " + token);
            return execution.execute(request, body);
        }
    }
}
