package com.hand.hap.cloud.devops.service.impl;

import com.hand.hap.cloud.devops.service.GitService;
import com.hand.hap.cloud.resource.exception.HapException;
import org.apache.commons.io.FileUtils;
import org.eclipse.jgit.api.CheckoutCommand;
import org.eclipse.jgit.api.CreateBranchCommand;
import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.api.errors.GitAPIException;
import org.eclipse.jgit.internal.storage.file.FileRepository;
import org.eclipse.jgit.lib.Ref;
import org.eclipse.jgit.transport.CredentialsProvider;
import org.eclipse.jgit.transport.UsernamePasswordCredentialsProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * Created by qs on 2017/11/7.
 */
@Service
public class GitServiceImpl implements GitService {

    private ResourceLoader resourceLoader = new DefaultResourceLoader();
    private String classPath;
    private static final Logger logger = LoggerFactory.getLogger(GitServiceImpl.class);

    private static final String REPONAME = "hap-devops-cloud-repo";

    public GitServiceImpl() {
        try {
            this.classPath = resourceLoader.getResource("/").getURI().getPath();
            String repositoryPath = this.classPath == null ? "" : this.classPath + REPONAME;
            File repo = new File(repositoryPath);
            if (!repo.exists()) {
                repo.mkdirs();
            }
        } catch (IOException io) {
            logger.error(io.getMessage());
        }
    }

    @Override
    public Git clone(String name, String remoteUrl) {
        Git git = null;
        String workingDirectory = getWorkingDirectory(name);
        File localPathFile = new File(workingDirectory);
        if (localPathFile.exists()) {
            deleteDir(localPathFile);
        }
        try {
            CredentialsProvider cp = new UsernamePasswordCredentialsProvider("root", "handhand");
            git = Git.cloneRepository()
                    .setURI(remoteUrl)
                    .setBranch("master")
                    .setDirectory(localPathFile)
                    .setCredentialsProvider(cp).call();
        } catch (GitAPIException e) {
            throw new HapException("error.git.clone");
        }
        return git;
    }


    /**
     * 判断某部署的仓库目录是否存在
     *
     * @param name
     * @return
     */
    @Override
    public File exists(String name) {
        Git git = null;
        FileRepository fileRepository =null;
        try {
            String workingDirectory = getWorkingDirectory(name);
            File localPathFile = new File(workingDirectory, ".git");
            fileRepository=  new FileRepository(localPathFile);
            git = new Git(fileRepository);
            if (git.getRepository().getConfig() != null) {
                return localPathFile;
            }
            if(git != null){
                git.close();
            }
        } catch (IOException io) {
            return null;
        } finally {
            if(fileRepository != null){
                fileRepository.close();
            }
            if (git != null) {
                git.close();
            }
        }
        return null;
    }

    @Override
    public String getWorkingDirectory(String name) {
        String path = this.classPath == null ? REPONAME + "/" + name : this.classPath + REPONAME + "/" + name;
        return path.replace("/", File.separator);

    }

    @Override
    public void deleteWorkingDirectory(String name) {
        String path = getWorkingDirectory(name);
        File file = new File(path);
        if (file.exists()) {
            deleteDir(file);
        }
    }

    @Override
    public Git getGitByOpen(File file) throws IOException {
        Git git = Git.open(file);
        return git;
    }

    @Override
    public List<String> getTags(Git git) throws GitAPIException {
        List<String> tags = new ArrayList<>();
        git.fetch().call();
        Collection<Ref> refs = git.lsRemote().setTags(true).call();
        for (Ref t : refs) {
            String [] ref = t.getName().split("/");
            String tagName = ref[ref.length - 1];
            tags.add(tagName);
        }
        return tags;
    }

    @Override
    public void deleteLocalTags(Git git) {
        //获取本地tag列表,并删除
        try {
            List<Ref> localRefs = git.tagList().call();
            for (Ref t : localRefs) {
                String [] ref = t.getName().split("/");
                String tagName = ref[ref.length - 1];
                git.tagDelete().setTags(tagName).call();
            }
        } catch (GitAPIException e) {
            logger.error(e.getMessage());
        }
    }

    @Override
    public void checkoutTag(Git git, String tag) {
        try {
            CheckoutCommand checkout = git.checkout();
            checkout.setName(tag);
            checkout.call();
        } catch (GitAPIException e) {
            throw new HapException("error.git.checkout", tag);
        }
    }

    @Override
    public String readFile(String name, String fileName) {
        String filePath = getWorkingDirectory(name) + File.separator + fileName;
        File file = new File(filePath);
        if(!file.exists()){
            return "";
        }
        try {
            return FileUtils.readFileToString(file, "UTF-8");
        } catch (IOException e) {
            throw new HapException("error.git.readFile", fileName);
        }
    }

    @Override
    public void gitPull(Git git){
        try {
            CredentialsProvider cp = new UsernamePasswordCredentialsProvider("root", "handhand");
            git.pull().setRemoteBranchName("master").setCredentialsProvider(cp).call();
        }  catch (GitAPIException e) {
            logger.error(e.getMessage());
            throw new HapException("error.git.pull");
        }
    }

    @Override
    public void gitCreateBranch(Git git,boolean flag){
        try{
            git.checkout()
                    .setCreateBranch(flag)
                    .setName("master")
                    .setUpstreamMode(CreateBranchCommand.SetupUpstreamMode.TRACK)
                    .setStartPoint("origin/master")
                    .setForce(true)
                    .call();
        }catch (GitAPIException e){
            logger.error(e.getMessage());
            throw new HapException("error.git.create.branch");
        }
    }

    private boolean deleteDir(File dir) {
        if (dir.isDirectory()) {
            String[] children = dir.list();
            for (int i = 0; i < children.length; i++) {
                boolean success = deleteDir(new File(dir, children[i]));
                if (!success) {
                    return false;
                }
            }
        }
        // 目录此时为空，可以删除
        return dir.delete();
    }
}
