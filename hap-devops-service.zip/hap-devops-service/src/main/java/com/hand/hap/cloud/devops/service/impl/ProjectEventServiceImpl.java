package com.hand.hap.cloud.devops.service.impl;

import com.hand.hap.cloud.devops.client.HapCloudUserFeign;
import com.hand.hap.cloud.devops.client.ProjectFeign;
import com.hand.hap.cloud.devops.domain.gitlab.Group;
import com.hand.hap.cloud.devops.domain.gitlab.ProjectAttrs;
import com.hand.hap.cloud.devops.domain.project.ProjectEventMsg;
import com.hand.hap.cloud.devops.domain.service.HapcloudProject;
import com.hand.hap.cloud.devops.service.ProjectEventService;
import com.hand.hap.cloud.mybatis.service.BaseServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public class ProjectEventServiceImpl extends BaseServiceImpl<ProjectAttrs> implements ProjectEventService{
    @Autowired
    private ProjectFeign projectFeign;

    @Autowired
    private HapCloudUserFeign hapCloudUserFeign;

    @Override
    public ResponseEntity projectEventProc(Long organizationId,ProjectEventMsg projectEventMsg) {
        Long id;
        HapcloudProject hapcloudProject = new HapcloudProject();
        hapcloudProject.setCode(projectEventMsg.getCode());
        hapcloudProject.setName(projectEventMsg.getName());
        if (projectEventMsg.getOperationType().equalsIgnoreCase("CREATE")) {
            ResponseEntity<HapcloudProject> hapcloudProjectResponseEntity = hapCloudUserFeign.crete(organizationId, hapcloudProject);
            HapcloudProject resHapcloudProject = hapcloudProjectResponseEntity.getBody();
            // 获取框架项目id
            id = resHapcloudProject.getId();
        }else{
            id = projectEventMsg.getId();
        }
        String code = projectEventMsg.getCode();
        String name = projectEventMsg.getName();
        if (projectEventMsg.getOperationType().equalsIgnoreCase("CREATE")) {
            ResponseEntity<Group> group = projectFeign.addProject(code, name);
            if(group.getStatusCodeValue()==200) {
                //TODO:添加root用户到新建的组
                ProjectAttrs projectAttrs = new ProjectAttrs();
                projectAttrs.setId(id);
                projectAttrs.setGitlabGroupId(group.getBody().getId().longValue());
                insert(projectAttrs);
                return new ResponseEntity(HttpStatus.OK);
            }
            else{
                hapCloudUserFeign.delete(organizationId,id);
                return new ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } else if (projectEventMsg.getOperationType().equalsIgnoreCase("UPDATE")) {
            ProjectAttrs projectAttrs = selectByPrimaryKey(projectEventMsg.getId());
            HapcloudProject hapcloudProject1 = hapCloudUserFeign.queryHapcloudProject(organizationId,projectAttrs.getId()).getBody();
            ResponseEntity response = projectFeign.updateProject(projectAttrs.getGitlabGroupId().intValue(), projectEventMsg.getCode(), projectEventMsg.getName());
            if (response.getStatusCodeValue() == 200){
                hapcloudProject1.setName(hapcloudProject.getName());
                hapcloudProject1.setCode(hapcloudProject.getCode());
                hapCloudUserFeign.update(organizationId,projectAttrs.getId(),hapcloudProject1);
            }
        } else if (projectEventMsg.getOperationType().equalsIgnoreCase("DELETE")) {
            ProjectAttrs projectAttrs = selectByPrimaryKey(projectEventMsg.getId());
            ResponseEntity responseEntity = projectFeign.dateleProject(projectAttrs.getGitlabGroupId().intValue());
            if (responseEntity.getStatusCodeValue() == 204){
                delete(projectAttrs);
                hapCloudUserFeign.delete(organizationId,projectAttrs.getId());
            }
        }
        return new ResponseEntity(HttpStatus.NO_CONTENT);
    }
}
