package com.hand.hap.cloud.devops.service.impl;

import com.hand.hap.cloud.devops.domain.serviceRelease.ServiceRelease;
import com.hand.hap.cloud.devops.mapper.ServiceReleaseMapper;
import com.hand.hap.cloud.devops.service.ServiceReleaseService;
import com.hand.hap.cloud.mybatis.service.BaseServiceImpl;
import com.hand.hap.cloud.resource.exception.HapException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ServiceReleaseServiceImpl extends BaseServiceImpl<ServiceRelease> implements ServiceReleaseService {

    @Autowired
    private ServiceReleaseMapper serviceReleaseMapper;

    @Override
    public ServiceRelease create(Long serviceVersionId, Long environmentId) {
        ServiceRelease serviceReleaseCur = new ServiceRelease();
        serviceReleaseCur.setServiceVersionId(serviceVersionId);
        serviceReleaseCur.setEnvironmentId(environmentId);
        if (serviceReleaseMapper.select(serviceReleaseCur).isEmpty()) {
            ServiceRelease serviceRelease = new ServiceRelease();
            serviceRelease.setServiceVersionId(serviceVersionId);
            serviceRelease.setEnvironmentId(environmentId);
            serviceReleaseMapper.insert(serviceRelease);
            return serviceRelease;
        } else {
            throw new HapException("error.serviceVersion.release.exist");
        }
    }
}
