package com.hand.hap.cloud.devops.service.impl;

import com.hand.hap.cloud.devops.domain.service.ServiceType;
import com.hand.hap.cloud.devops.mapper.ServiceTypeMapper;
import com.hand.hap.cloud.devops.service.ServiceTypeService;
import com.hand.hap.cloud.mybatis.service.BaseServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Created with IntelliJ IDEA.
 * Description:
 * User: huangfengrun
 * Date: 2017-11-08
 */
@Service
public class ServiceTypeServiceImpl extends BaseServiceImpl<ServiceType>  implements ServiceTypeService {
    @Autowired
    private  ServiceTypeMapper serviceTypeMapper;

    @Override
    public ServiceType create(ServiceType serviceType) {
        serviceTypeMapper.insert(serviceType);
        return serviceType;
    }

    @Override
    public ServiceType modify(ServiceType serviceType) {
        updateByPrimaryKey(serviceType);
        return serviceType;
    }

    @Override
    public boolean delete(Long id) {
        serviceTypeMapper.deleteByPrimaryKey(id);
        return true;
    }
}
