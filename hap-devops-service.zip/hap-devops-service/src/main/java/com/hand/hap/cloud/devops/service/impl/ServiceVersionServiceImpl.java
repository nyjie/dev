package com.hand.hap.cloud.devops.service.impl;

import com.hand.hap.cloud.devops.domain.service.DevopsService;
import com.hand.hap.cloud.devops.domain.service.ServiceType;
import com.hand.hap.cloud.devops.domain.serviceVersion.ServiceCiInfo;
import com.hand.hap.cloud.devops.domain.serviceVersion.ServiceVersion;
import com.hand.hap.cloud.devops.domain.serviceVersion.ServiceVersionReleaseEntity;
import com.hand.hap.cloud.devops.mapper.*;
import com.hand.hap.cloud.devops.service.ServiceVersionService;
import com.hand.hap.cloud.mybatis.pagehelper.domain.Page;
import com.hand.hap.cloud.mybatis.service.BaseServiceImpl;
import com.hand.hap.cloud.resource.exception.HapException;
import org.jtwig.JtwigModel;
import org.jtwig.JtwigTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class ServiceVersionServiceImpl extends BaseServiceImpl<ServiceVersion> implements ServiceVersionService {

    @Autowired
    private ServiceVersionMapper serviceVersionMapper;

    @Autowired
    private ServiceTypeMapper serviceTypeMapper;

    @Autowired
    private DevopsServiceMapper devopsServiceMapper;

    @Autowired
    private ServiceVersionService serviceVersionService;

    @Autowired
    private ServiceReleaseMapper serviceReleaseMapper;

    @Autowired
    private ServiceVersionReleaseMapper serviceVersionReleaseMapper;

    private final String serviceCodeName = "SERVICE_CODE";
    private final String serviceImageName = "SERVICE_IMAGE";
    private final String managementPortName = "MANAGEMENT_PORT";
    private final String portName = "PORT";
    private final String limitsMemoryName = "LIMITS_MEMORY";
    private final String requestsMemoryName = "REQUESTS_MEMORY";

    @Override
    public ServiceVersion create(ServiceCiInfo serviceCiInfo, Long serviceId) {
        DevopsService devopsService = devopsServiceMapper.selectByPrimaryKey(serviceId);
        ServiceType serviceType = serviceTypeMapper.selectByPrimaryKey(devopsService.getServiceTypeId());
        if (serviceType.getCode().equals(serviceCiInfo.getKind())) {
            ServiceVersion serviceVersion = new ServiceVersion();
            serviceVersion.setServiceId(serviceId);
            serviceVersion.setVersion(serviceCiInfo.getVersion());
            serviceVersion.setCommit(serviceCiInfo.getCommit());
            serviceVersion.setImage(serviceCiInfo.getImage());
            JtwigTemplate deploymentTemplate = null;
            if (serviceType.getCode().contains("Micro")) {
                deploymentTemplate = JtwigTemplate.classpathTemplate("/template/microService/deployment.template.yml");
            } else if (serviceType.getCode().contains("Web")) {
                deploymentTemplate = JtwigTemplate.classpathTemplate("/template/frontEnd/deployment.template.yml");
            }
            JtwigModel model = JtwigModel.newModel();
            if (!serviceCiInfo.getCode().isEmpty()) {
                model.with(serviceCodeName, serviceCiInfo.getCode());
            }
            if (!serviceCiInfo.getImage().isEmpty()) {
                model.with(serviceImageName, serviceCiInfo.getImage());
            }
            if (!("null".equalsIgnoreCase(String.valueOf(serviceCiInfo.getManagementPort())) || "0".equalsIgnoreCase(String.valueOf(serviceCiInfo.getManagementPort())))) {
                model.with(managementPortName, String.valueOf(serviceCiInfo.getManagementPort()));
            }
            if (!("null".equalsIgnoreCase(String.valueOf(serviceCiInfo.getPort())) || "0".equalsIgnoreCase(String.valueOf(serviceCiInfo.getPort())))) {
                model.with(portName, String.valueOf(serviceCiInfo.getPort()));
            }
            if (!serviceCiInfo.getResources().getLimits().getMemory().isEmpty()) {
                model.with(limitsMemoryName, serviceCiInfo.getResources().getLimits().getMemory());
            }
            if (!serviceCiInfo.getResources().getRequests().getMemory().isEmpty()) {
                model.with(requestsMemoryName, serviceCiInfo.getResources().getRequests().getMemory());
            }
            String deployment = deploymentTemplate.render(model);
            serviceVersion.setDeployment(deployment);
            serviceVersionMapper.insert(serviceVersion);
            return serviceVersion;
        } else {
            throw new HapException("error.serviceType.invaild");
        }
    }

    @Override
    public List<ServiceVersionReleaseEntity> queryByServiceId(Long serviceId, int page, int size) {
        List<ServiceVersionReleaseEntity> serviceVersionReleaseEntities = new ArrayList<>();
        ServiceVersion serviceVersion = new ServiceVersion();
        serviceVersion.setServiceId(serviceId);
        Page<ServiceVersion> serviceVersions = serviceVersionService.page(serviceVersion, page, size);
        List<ServiceVersion> serviceVersionList = serviceVersions.getContent();
        for (ServiceVersion serviceVersion1 : serviceVersionList) {
            ServiceVersionReleaseEntity serviceVersionReleaseEntity = new ServiceVersionReleaseEntity();
            List<String> envNames = serviceReleaseMapper.findEnvByServiceVersionId(serviceVersion1.getId());
            serviceVersionReleaseEntity.setServiceVersion(serviceVersion1);
            serviceVersionReleaseEntity.setEnvName(envNames);
            serviceVersionReleaseEntities.add(serviceVersionReleaseEntity);
        }
        return serviceVersionReleaseEntities;
    }

}
