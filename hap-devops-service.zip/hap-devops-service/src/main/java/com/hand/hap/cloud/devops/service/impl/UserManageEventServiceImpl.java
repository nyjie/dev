package com.hand.hap.cloud.devops.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hand.event.consumer.helper.Topic;
import com.hand.event.consumer.helper.retry.AfterRetryFailedHandler;
import com.hand.hap.cloud.devops.client.UserFeign;
import com.hand.hap.cloud.devops.domain.user.UserEventMsg;
import com.hand.hap.cloud.devops.domain.user.UserProcMsg;
import com.hand.hap.cloud.devops.service.UserManageEventService;
import com.hand.hap.cloud.resource.exception.HapException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.Date;

/**
 * Created by huangfengrun on 2017/11/7.
 */
@Service
public class UserManageEventServiceImpl implements UserManageEventService {
    private ObjectMapper mapper = new ObjectMapper();
    @Autowired
    private UserFeign userFeign;
    private static final Logger logger = LoggerFactory.getLogger(UserManageEventServiceImpl.class);

    @Topic(value = "UserOperator", afterRetryFailedHandler = MyAfter.class)
    @Override
    public ResponseEntity userManageEventProc(String msg) {
        logger.info("=== 消息队列接收信息 : {}", msg);
        UserEventMsg  userEventMsg = null;
        try {
            userEventMsg = mapper.readValue(msg, UserEventMsg.class);
            System.out.println(userEventMsg.getEmail());
        } catch (IOException e) {
            e.printStackTrace();
        }
        UserProcMsg userProcMsg = new UserProcMsg();

        userProcMsg.setExternUid(userEventMsg.getId());
        userProcMsg.setProvider("oauth2_generic");

        userProcMsg.setUsername(userEventMsg.getUsername());
        userProcMsg.setEmail(userEventMsg.getEmail());
        userProcMsg.setName(userEventMsg.getUsername());
        userProcMsg.setCanCreateGroup(true);
        userProcMsg.setConfirmedAt(new Date());
        userProcMsg.setProjectsLimit(100);
        if (userEventMsg.getOperationType().equalsIgnoreCase("CREATE")) {
            return userFeign.createGitLabUser(userProcMsg, "handhand", 100);
        } else if (userEventMsg.getOperationType().equalsIgnoreCase("DELETE")) {
            return userFeign.deleteGitLabUser(userEventMsg.getUsername());
        } else if (userEventMsg.getOperationType().equalsIgnoreCase("UPDATE")) {
            return userFeign.modifyGitLabUser(userProcMsg, "handhand", 100);
        }
        throw new HapException("error.member.update");
    }


    class MyAfter implements AfterRetryFailedHandler {
        @Override
        public void handleMsg(String s) {

        }
    }
}
