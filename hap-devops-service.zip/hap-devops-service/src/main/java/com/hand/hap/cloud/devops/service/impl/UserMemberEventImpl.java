package com.hand.hap.cloud.devops.service.impl;

//import com.han.event.consumer.helper.Topic;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hand.event.consumer.helper.Topic;
import com.hand.event.consumer.helper.retry.AfterRetryFailedHandler;
import com.hand.hap.cloud.devops.client.MemberFeign;
import com.hand.hap.cloud.devops.domain.gitlab.Member;
import com.hand.hap.cloud.devops.domain.gitlab.ProjectAttrs;
import com.hand.hap.cloud.devops.domain.gitlab.User;
import com.hand.hap.cloud.devops.domain.user.UserEventMsg;
import com.hand.hap.cloud.devops.domain.usermember.UserMemberEventMsg;
import com.hand.hap.cloud.devops.domain.usermember.UserMemberProcMsg;
import com.hand.hap.cloud.devops.service.UserMemberEventService;
import com.hand.hap.cloud.devops.utils.TypeUtils;
import com.hand.hap.cloud.mybatis.service.BaseServiceImpl;
import com.hand.hap.cloud.resource.exception.HapException;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.*;

@Service
public class UserMemberEventImpl extends BaseServiceImpl<ProjectAttrs> implements UserMemberEventService {
    private ObjectMapper mapper = new ObjectMapper();
    private static final Logger logger = LoggerFactory.getLogger(UserManageEventServiceImpl.class);

    @Autowired
    private MemberFeign memberFeign;

    @Override
    @Topic(value = "UserRoleOperator",
            afterRetryFailedHandler = UserManageEventServiceImpl.MyAfter.class)
    //TODO:框架完善事件发布后更改参数并且回复代码。
    public ResponseEntity userMemberEventProc(String msg) {
        logger.info("=== 消息队列接收信息1 : {}", msg);
        UserMemberEventMsg userMemberEventMsg = null;
        try {
            userMemberEventMsg = mapper.readValue(msg,UserMemberEventMsg.class);
        } catch (IOException e) {
            e.printStackTrace();
        }
        UserMemberProcMsg userMemberProcMsg = new UserMemberProcMsg();
        userMemberProcMsg.setAccessLevel(0);
        try {
            List<String> usermemberList = userMemberEventMsg.getUsermember();
            Iterator<String> usermemberIt = usermemberList.iterator();
            List<Integer> accessLevelList = new ArrayList<>();
            while (usermemberIt.hasNext()){
                switch (usermemberIt.next().toUpperCase()){
                    case "OWNER" :
                        accessLevelList.add(50);
                        break;
                    case "MASTER" :
                        accessLevelList.add(40);
                        break;
                    case "DEVELOPER" :
                        accessLevelList.add(30);
                        break;
                    case "REPORTER" :
                        accessLevelList.add(20);
                        break;
                    case "GUEST" :
                        accessLevelList.add(10);
                        break;
                    default:
                        break;
                }
            }
            if (!accessLevelList.isEmpty()){
                userMemberProcMsg.setAccessLevel(Collections.max(accessLevelList));
            }
            userMemberProcMsg.setUserName(userMemberEventMsg.getUsername());
            userMemberProcMsg.setGroupCreator("root");
            userMemberProcMsg.setExpiresAt("");
            isOperation(userMemberEventMsg.getProjectId(), userMemberProcMsg);
            return new ResponseEntity(HttpStatus.OK);
        }catch (Exception e){
            e.printStackTrace();
            throw new HapException("error.member.event.parse");
        }
    }

    public void isOperation(Long projectId,UserMemberProcMsg userMemberProcMsg){
        if(isTrue(userMemberProcMsg) != null){
            throw new HapException(isTrue(userMemberProcMsg)+"  is empty");
        }

        //根据username获取userId
        ResponseEntity<User> userResponseEntity = memberFeign.queryUserByUsername(userMemberProcMsg.getUserName());
        if(userResponseEntity.getStatusCode() != HttpStatus.OK){
            throw new HapException("error.user.get");
        }
        User user = userResponseEntity.getBody();

        //获取gitlab的groupId
       ProjectAttrs projectAttrs = selectByPrimaryKey(projectId);
        if(projectAttrs == null){
            throw new HapException("get gitlab groupId is error");
        }

        //查询该组存不存在该用户
        ResponseEntity<Member> memberResponseEntity = memberFeign.queryGroupMember(TypeUtils.objToInteger(projectAttrs.getGitlabGroupId()), user.getId());
        if(memberResponseEntity.getStatusCode() != HttpStatus.OK){
            throw new HapException("error.group.member.get");
        }
        Member member = memberResponseEntity.getBody();

        if(userMemberProcMsg.getAccessLevel() == 0 && member != null){
            //删除该组成员
            ResponseEntity removeMember = memberFeign.removeMember(TypeUtils.objToInteger(projectAttrs.getGitlabGroupId()), user.getId());
            if(removeMember.getStatusCode() != HttpStatus.NO_CONTENT){
                throw new HapException("error.remove.member");
            }
            return;
        }

        if(!isAccessLevel(userMemberProcMsg.getAccessLevel())){
                throw new HapException("group member access level is 10 or 20 or 30 or 40 or 50");
        }

        if(member == null){
            ResponseEntity addMember = memberFeign.addMember(TypeUtils.objToInteger(projectAttrs.getGitlabGroupId()),user.getId(),userMemberProcMsg.getAccessLevel(),userMemberProcMsg.getExpiresAt());
            if(addMember.getStatusCode() != HttpStatus.OK){
                throw new HapException("error.add.member");
            }
        }else{
            ResponseEntity addMember = memberFeign.updateMember(TypeUtils.objToInteger(projectAttrs.getGitlabGroupId()),user.getId(),userMemberProcMsg.getAccessLevel(),userMemberProcMsg.getExpiresAt());
            if(addMember.getStatusCode() != HttpStatus.OK){
                throw new HapException("error.update.member");
            }
        }
    }

    public Object isTrue(UserMemberProcMsg userMemberProcMsg){
        if(StringUtils.isEmpty(userMemberProcMsg.getUserName())){
            return "userName";
        }
        if(StringUtils.isEmpty(userMemberProcMsg.getGroupCreator())){
            return "groupCreator";
        }
        if(StringUtils.isEmpty(TypeUtils.objToString(userMemberProcMsg.getAccessLevel()))){
            return "accessLevel";
        }
        return null;
    }

    public boolean isAccessLevel(int access_level){
        List<Integer> list = Arrays.asList(10,20,30,40,50);
        if(list.contains(access_level)){
            return true;
        }
        return false;
    }

    class MyAfter implements AfterRetryFailedHandler {
        @Override
        public void handleMsg(String s) {

        }
    }
}