package com.hand.hap.cloud.devops.utils;

/**
 * Created by qs on 2017/11/6.
 */
public class TypeUtils {

    public static String objToString(Object obj) {
        if (obj == null) {
            return null;
        }
        return String.valueOf(obj);
    }

    public static Integer objToInteger(Object obj) {
        if (obj == null) {
            return null;
        }
        return Integer.valueOf(String.valueOf(obj));
    }

    public static Long objToLong(Object obj) {
        if (obj == null) {
            return null;
        }
        return Long.valueOf(String.valueOf(obj));
    }

    public static long objTolong(Object obj) {
        if (obj == null) {
            return 0L;
        }
        return Long.parseLong(String.valueOf(obj));
    }

    public static double objTodouble(Object obj) {
        if (obj == null) {
            return 0;
        }
        return Double.parseDouble(String.valueOf(obj));
    }

    public static int objToInt(Object obj) {
        if (obj == null) {
            return 0;
        }
        return Integer.parseInt(String.valueOf(obj));
    }

    public static Boolean objToBoolean(Object obj) {
        if (obj == null) {
            return null;
        }
        return Boolean.valueOf(String.valueOf(obj));
    }

}
