package db

databaseChangeLog(logicalFilePath: '2017-11-14-devops.groovy') {
    changeSet(author: 'HuangFuqiang', id: '2017-11-14') {
        createTable(tableName: "service", remarks: '服务') {
            column(name: 'id', type: 'BIGINT', autoIncrement: true, remarks: 'ID') {
                constraints(primaryKey: true)
            }
            column(name: 'name', type: 'VARCHAR(32)', remarks: '名称')
            column(name: 'project_id', type: 'BIGINT', remarks: '项目ID')
            column(name: 'service_type_id', type: 'BIGINT', remarks: '服务ID')
            column(name: 'gitlab_project_id', type: 'BIGINT', remarks: 'gitlab项目id')
            column(name: 'code', type: 'VARCHAR(64)', remarks: '服务编码')

            column(name: "OBJECT_VERSION_NUMBER", type: "BIGINT", defaultValue: "1")
            column(name: "CREATED_BY", type: "BIGINT", defaultValue: "-1")
            column(name: "CREATION_DATE", type: "DATETIME", defaultValueComputed: "CURRENT_TIMESTAMP")
            column(name: "LAST_UPDATED_BY", type: "BIGINT", defaultValue: "-1")
            column(name: "LAST_UPDATE_DATE", type: "DATETIME", defaultValueComputed: "CURRENT_TIMESTAMP")
        }
        createTable(tableName: "service_type", remarks: '服务类型') {
            column(name: 'id', type: 'BIGINT',autoIncrement: true, remarks: 'ID') {
                constraints(primaryKey: true)
            }
            column(name: 'name', type: 'VARCHAR(32)', remarks: '名称')
            column(name: 'repo_path', type: 'text', remarks: 'repo_path')

            column(name: "OBJECT_VERSION_NUMBER", type: "BIGINT", defaultValue: "1")
            column(name: "CREATED_BY", type: "BIGINT", defaultValue: "-1")
            column(name: "CREATION_DATE", type: "DATETIME", defaultValueComputed: "CURRENT_TIMESTAMP")
            column(name: "LAST_UPDATED_BY", type: "BIGINT", defaultValue: "-1")
            column(name: "LAST_UPDATE_DATE", type: "DATETIME", defaultValueComputed: "CURRENT_TIMESTAMP")
        }

        createTable(tableName: "project_attrs", remarks: '项目扩展表') {
            column(name: 'id', type: 'BIGINT', remarks: 'ID') {
                constraints(primaryKey: true)
            }
            column(name: 'gitlab_group_id', type: 'BIGINT', remarks: 'gitlab组id')

            column(name: "OBJECT_VERSION_NUMBER", type: "BIGINT", defaultValue: "1")
            column(name: "CREATED_BY", type: "BIGINT", defaultValue: "-1")
            column(name: "CREATION_DATE", type: "DATETIME", defaultValueComputed: "CURRENT_TIMESTAMP")
            column(name: "LAST_UPDATED_BY", type: "BIGINT", defaultValue: "-1")
            column(name: "LAST_UPDATE_DATE", type: "DATETIME", defaultValueComputed: "CURRENT_TIMESTAMP")
        }

        createTable(tableName: "environment",remarks: '环境管理'){
            column(name: 'id', type: 'BIGINT',autoIncrement: true, remarks: 'ID') {
                constraints(primaryKey: true)
            }
            column(name: 'name', type: 'VARCHAR(32)', remarks: '名称'){
                constraints(nullable: false)
            }
            column(name: 'organization_id', type: 'BIGINT', remarks: '组织ID') {
                constraints(nullable: false)
            }
            column(name: 'url', type: 'VARCHAR(256)', remarks: '地址'){
                constraints(nullable: false)
            }
            column(name: 'token', type: 'VARCHAR(256)', remarks: 'token')

            column(name: "OBJECT_VERSION_NUMBER", type: "BIGINT", defaultValue: "1")
            column(name: "CREATED_BY", type: "BIGINT", defaultValue: "-1")
            column(name: "CREATION_DATE", type: "DATETIME", defaultValueComputed: "CURRENT_TIMESTAMP")
            column(name: "LAST_UPDATED_BY", type: "BIGINT", defaultValue: "-1")
            column(name: "LAST_UPDATE_DATE", type: "DATETIME", defaultValueComputed: "CURRENT_TIMESTAMP")
        }
    }
    changeSet(author: 'ChaiYuchen', id: '2017-11-14') {
        createTable(tableName: "service_version", remarks: 'Service版本表') {
            column(name: 'id', type: 'BIGINT', remarks: 'ID', autoIncrement: true) {
                constraints(primaryKey: true)
            }
            column(name: 'version', type: 'VARCHAR(64)', remarks: '版本号')
            column(name: 'service_id', type: 'BIGINT', remarks: '服务id')
            column(name: 'deployment', type: 'TEXT', remarks: '部署文件')
            column(name: 'image', type: 'VARCHAR(256)', remarks: '镜像名')
            column(name: 'commit', type: 'VARCHAR(256)', remarks: 'commit Hash或Tag')

            column(name: "OBJECT_VERSION_NUMBER", type: "BIGINT", defaultValue: "1")
            column(name: "CREATED_BY", type: "BIGINT", defaultValue: "-1")
            column(name: "CREATION_DATE", type: "DATETIME", defaultValueComputed: "CURRENT_TIMESTAMP")
            column(name: "LAST_UPDATED_BY", type: "BIGINT", defaultValue: "-1")
            column(name: "LAST_UPDATE_DATE", type: "DATETIME", defaultValueComputed: "CURRENT_TIMESTAMP")
        }
        addColumn(tableName: 'service') {
            column(name: "group_name", type: "VARCHAR(256)", remarks: "servcie所属的组") {
                constraints(nullable: true)
            }
        }
        addColumn(tableName: 'service_type') {
            column(name: "code", type: "VARCHAR(64)", remarks: "serviceType的code")
        }
    }
    changeSet(author: "ChaiYuchen", id: "2017.11.15") {
        createTable(tableName: "service_release", remarks: 'Service发布表') {
            column(name: 'id', type: 'BIGINT', remarks: 'ID', autoIncrement: true) {
                constraints(primaryKey: true)
            }
            column(name: 'service_version_id', type: 'BIGINT', remarks: '发布版本号')
            column(name: 'environment_id', type: 'BIGINT', remarks: '环境id')

            column(name: "OBJECT_VERSION_NUMBER", type: "BIGINT", defaultValue: "1")
            column(name: "CREATED_BY", type: "BIGINT", defaultValue: "-1")
            column(name: "CREATION_DATE", type: "DATETIME", defaultValueComputed: "CURRENT_TIMESTAMP")
            column(name: "LAST_UPDATED_BY", type: "BIGINT", defaultValue: "-1")
            column(name: "LAST_UPDATE_DATE", type: "DATETIME", defaultValueComputed: "CURRENT_TIMESTAMP")
        }
    }

    changeSet(author: 'Wangqinsheng', id: '2017-11-16-environment') {
        addUniqueConstraint(tableName: 'environment', columnNames: 'name');
    }
}