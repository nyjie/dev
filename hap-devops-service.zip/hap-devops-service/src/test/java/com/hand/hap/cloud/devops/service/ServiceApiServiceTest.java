package com.hand.hap.cloud.devops.service;

import com.hand.hap.cloud.devops.DevopsServiceApplication;
import com.hand.hap.cloud.devops.client.HapCloudUserFeign;
import com.hand.hap.cloud.devops.client.ServiceFeign;
import com.hand.hap.cloud.devops.domain.service.DevopsService;
import com.hand.hap.cloud.devops.domain.service.HapcloudProject;
import com.hand.hap.cloud.devops.domain.service.ServiceProcMsg;
import com.hand.hap.cloud.devops.domain.service.ServiceType;
import com.hand.hap.cloud.devops.mapper.DevopsServiceMapper;
import com.hand.hap.cloud.devops.mapper.ServiceTypeMapper;
import org.junit.Assert;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.when;

//@SpringBootTest(classes = DevopsServiceApplication.class)
//@RunWith(SpringRunner.class)
//@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ServiceApiServiceTest {

//    private static final String SUCCESS = "success";
//    private DevopsService devopsServiceTmp = new DevopsService();
//    private List<DevopsService> devopsServiceList = new ArrayList<>();
//    private ServiceType serviceTyp = new ServiceType();
//    private ServiceProcMsg serviceProcMsg = new ServiceProcMsg();
//    private HapcloudProject hapcloudProject = new HapcloudProject();
//
//    //注入的对象
//    @Autowired
//    @InjectMocks
//    private DevopsServiceService devopsServiceService;
//
//    //Mock依赖注入
//    @Mock
//    private HapCloudUserFeign hapCloudUserFeign;
//
//    @Mock
//    private DevopsServiceMapper devopsServiceMapper;
//
//    @Mock
//    private ServiceTypeMapper serviceTypeMapper;
//
//    @Mock
//    private ServiceFeign serviceFeign;
//
//    @Before
//    public void init(){
//        //初始化Mock对象
//        MockitoAnnotations.initMocks(this);
//    }
//
//    public void setDevopsServiceTmp(){
//        hapcloudProject.setCode("1");
//        devopsServiceTmp.setCode(System.currentTimeMillis()+"");
//        devopsServiceTmp.setName("test");
//        devopsServiceTmp.setProject(System.currentTimeMillis());
//        devopsServiceTmp.setServiceType(1L);
//        devopsServiceTmp.setGitlabServiceId(1L);
//        devopsServiceTmp.setId(1L);
//        devopsServiceTmp.setRepoUrl("");
//
//        serviceProcMsg.setOperater("root");
//        serviceProcMsg.setProjectCode(hapcloudProject.getCode());
//        serviceProcMsg.setServiceRepoPath("http://git.saas.hand-china.com/devops/template-front.git");
//        serviceProcMsg.setServiceName("test");
//        serviceProcMsg.setServiceTypeName("Web Front-end");
//        serviceProcMsg.setServiceCode("test");
//    }
//
//    @Test
//    public void A_createService(){
//        setDevopsServiceTmp();
//        when(devopsServiceMapper.select(Mockito.any(DevopsService.class))).thenReturn(devopsServiceList);
//        when(hapCloudUserFeign.queryHapcloudProject(Mockito.anyLong(),Mockito.anyLong())).thenReturn(new ResponseEntity<HapcloudProject>(hapcloudProject,HttpStatus.OK));
//        when(serviceTypeMapper.selectByPrimaryKey(Mockito.anyLong())).thenReturn(serviceTyp);
//        when(serviceFeign.createGitlabService(Mockito.anyLong(),Mockito.any(ServiceProcMsg.class))).thenReturn(devopsServiceTmp);
//        when(devopsServiceMapper.insert(Mockito.any(DevopsService.class))).thenReturn(1);
//
//        DevopsService devopsService = devopsServiceService.create(System.currentTimeMillis(), System.currentTimeMillis(), devopsServiceTmp);
//        Assert.assertNotNull(devopsService);
//    }
//
//    @Test
//    public void B_updateService(){
//        setDevopsServiceTmp();
//        when(devopsServiceMapper.selectByPrimaryKey(Mockito.anyLong())).thenReturn(devopsServiceTmp);
//        when(serviceFeign.updateGitlabService(Mockito.anyLong(),Mockito.anyString())).thenReturn(devopsServiceTmp);
//        when(devopsServiceMapper.updateByPrimaryKey(devopsServiceTmp)).thenReturn(1);
//        when(devopsServiceMapper.selectByPrimaryKey(Mockito.anyInt())).thenReturn(devopsServiceTmp);
//
//        DevopsService devopsService = devopsServiceService.update(System.currentTimeMillis(), System.currentTimeMillis()+"", System.currentTimeMillis()+"");
//        Assert.assertNotNull(devopsService);
//    }
//
//    @Test
//    public void C_deleteService(){
//        setDevopsServiceTmp();
//        when(devopsServiceMapper.selectByPrimaryKey(Mockito.anyLong())).thenReturn(devopsServiceTmp);
//        when(serviceFeign.deleteGitlabService(Mockito.anyLong())).thenReturn(new ResponseEntity(HttpStatus.NO_CONTENT));
//        when(devopsServiceMapper.deleteByPrimaryKey(Mockito.anyInt())).thenReturn(1);
//
//        Boolean bol = devopsServiceService.delete(System.currentTimeMillis(), System.currentTimeMillis());
//        Assert.assertTrue(bol);
//    }
}
