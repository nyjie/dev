//package com.hand.hap.cloud.devops.service;
//
//import com.hand.hap.cloud.devops.DevopsServiceApplication;
//import com.hand.hap.cloud.devops.domain.service.DevopsService;
//import com.hand.hap.cloud.devops.domain.service.ServiceType;
//import com.hand.hap.cloud.devops.domain.serviceVersion.*;
//import com.hand.hap.cloud.devops.mapper.DevopsServiceMapper;
//import com.hand.hap.cloud.devops.mapper.ServiceTypeMapper;
//import com.hand.hap.cloud.devops.mapper.ServiceVersionMapper;
//import com.hand.hap.cloud.resource.exception.HapException;
//import org.junit.Assert;
//import org.junit.FixMethodOrder;
//import org.junit.Rule;
//import org.junit.Test;
//import org.junit.rules.ExpectedException;
//import org.junit.runner.RunWith;
//import org.junit.runners.MethodSorters;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.Mockito;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.test.context.junit4.SpringRunner;
//
//import static org.mockito.Mockito.when;
//
//@SpringBootTest(classes = DevopsServiceApplication.class)
//@RunWith(SpringRunner.class)
//@FixMethodOrder(MethodSorters.NAME_ASCENDING)
//public class ServiceVersionServiceTest {
//    @Autowired
//    @InjectMocks
//    private ServiceVersionService serviceVersionService;
//
//    @Rule
//    public ExpectedException expectedException = ExpectedException.none();
//
//    @Autowired
//    @Mock
//    private ServiceVersionMapper serviceVersionMapper;
//
//    @Autowired
//    @Mock
//    private ServiceTypeMapper serviceTypeMapper;
//
//    @Autowired
//    @Mock
//    private DevopsServiceMapper devopsServiceMapper;
//
//    @Test
//    public void test1Create1() {
//        Long serviceId = 1L;
//        Long serviceTypeId = 1L;
//        Resources resources = new Resources();
//        Limits limits = new Limits();
//        Requests requests = new Requests();
//        limits.setMemory("testLMemory");
//        requests.setMemory("testRMemory");
//        resources.setLimits(limits);
//        resources.setRequests(requests);
//        ServiceCiInfo serviceCiInfo = new ServiceCiInfo();
//        serviceCiInfo.setVersion("testVersion");
//        serviceCiInfo.setCode("testCode");
//        serviceCiInfo.setCommit("testCommit");
//        serviceCiInfo.setGroup("testGroup");
//        serviceCiInfo.setImage("testImage");
//        serviceCiInfo.setKind("testKind");
//        serviceCiInfo.setManagementPort(8081);
//        serviceCiInfo.setResources(resources);
//        ServiceVersion serviceVersion = new ServiceVersion();
//        serviceVersion.setServiceId(serviceId);
//        serviceVersion.setVersion(serviceCiInfo.getVersion());
//        serviceVersion.setCommit(serviceCiInfo.getCommit());
//        serviceVersion.setImage(serviceCiInfo.getImage());
//        serviceVersion.setDeployment("testDeployment");
//        DevopsService devopsService = new DevopsService();
//        devopsService.setServiceTypeId(serviceTypeId);
//        when(devopsServiceMapper.selectByPrimaryKey(serviceId)).thenReturn(devopsService);
//        ServiceType serviceType = new ServiceType();
//        serviceType.setCode("testKind");
//        when(serviceTypeMapper.selectByPrimaryKey(serviceTypeId)).thenReturn(serviceType);
//        when(serviceVersionMapper.insert(Mockito.any(ServiceVersion.class))).thenReturn(1);
//        ServiceVersion serviceVersionCur = serviceVersionService.create(serviceCiInfo, serviceId);
//        Assert.assertEquals(serviceVersion.getServiceId(), serviceVersionCur.getServiceId());
//        Assert.assertEquals(serviceVersion.getCommit(), serviceVersionCur.getCommit());
//        Assert.assertEquals(serviceVersion.getImage(), serviceVersionCur.getImage());
//        Assert.assertEquals(serviceVersion.getVersion(), serviceVersionCur.getVersion());
//    }
//
//    @Test
//    public void test1Create2() {
//        Long serviceId = 1L;
//        Long serviceTypeId = 1L;
//        Resources resources = new Resources();
//        Limits limits = new Limits();
//        Requests requests = new Requests();
//        limits.setMemory("testLMemory");
//        requests.setMemory("testRMemory");
//        resources.setLimits(limits);
//        resources.setRequests(requests);
//        ServiceCiInfo serviceCiInfo = new ServiceCiInfo();
//        serviceCiInfo.setVersion("testVersion");
//        serviceCiInfo.setCode("testCode");
//        serviceCiInfo.setCommit("testCommit");
//        serviceCiInfo.setGroup("testGroup");
//        serviceCiInfo.setImage("testImage");
//        serviceCiInfo.setKind("errorKind");
//        serviceCiInfo.setManagementPort(8081);
//        serviceCiInfo.setResources(resources);
//        ServiceVersion serviceVersion = new ServiceVersion();
//        serviceVersion.setServiceId(serviceId);
//        serviceVersion.setVersion(serviceCiInfo.getVersion());
//        serviceVersion.setCommit(serviceCiInfo.getCommit());
//        serviceVersion.setImage(serviceCiInfo.getImage());
//        serviceVersion.setDeployment("testDeployment");
//        DevopsService devopsService = new DevopsService();
//        devopsService.setServiceTypeId(serviceTypeId);
//        when(devopsServiceMapper.selectByPrimaryKey(serviceId)).thenReturn(devopsService);
//        ServiceType serviceType = new ServiceType();
//        serviceType.setCode("testKind");
//        when(serviceTypeMapper.selectByPrimaryKey(serviceTypeId)).thenReturn(serviceType);
//        when(serviceVersionMapper.insert(Mockito.any(ServiceVersion.class))).thenReturn(1);
//        expectedException.expect(HapException.class);
//        expectedException.expectMessage("error.serviceType.invaild");
//        ServiceVersion serviceVersionCur = serviceVersionService.create(serviceCiInfo, serviceId);
//    }
//}
