package com.hand.hap.cloud.devops.service;

import com.hand.hap.cloud.devops.client.UserFeign;
import com.hand.hap.cloud.devops.domain.user.UserEventMsg;
import com.hand.hap.cloud.devops.domain.user.UserProcMsg;
import org.junit.Assert;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import static org.mockito.Mockito.when;

/**
 * Created by HuangFuqinag on 2017/11/13.
 */
//@SpringBootTest
//@RunWith(SpringRunner.class)
//@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class UserApiServiceTest {

//    public static final String SUCCESS = "success";
//
//    private UserEventMsg userEventMsg;
//    private UserProcMsg userProcMsg;
//
//    @Autowired
//    @InjectMocks
//    private UserManageEventService userManageEventService;
//
//    @Mock
//    private UserFeign userFeign;
//
//    @Before
//    public void init() {
//        MockitoAnnotations.initMocks(this);
//    }
//
//    public void initUserEntity(String operation) {
//        userEventMsg = new UserEventMsg();
//        String username = "test" + System.currentTimeMillis();
//        String id = System.currentTimeMillis() + "";
//        String email = System.currentTimeMillis() + "@qq.com";
//        userEventMsg.setOperationType(operation);
//        userEventMsg.setUsername(username);
//        userEventMsg.setId(id);
//        userEventMsg.setEmail(email);
//        userEventMsg.setOrganizationId(1L);
//
//        userProcMsg = new UserProcMsg();
//        userProcMsg.setName(username);
//        userProcMsg.setUsername(username);
//        userProcMsg.setEmail(email);
//    }
//
//    @Test
//    public void A_createGitlabUserTest() {
//        when(userFeign.createGitLabUser(Mockito.anyLong(), Mockito.any(UserProcMsg.class), Mockito.anyString(), Mockito.anyInt())).thenReturn(new ResponseEntity<>(SUCCESS, HttpStatus.OK));
//        initUserEntity("CREATE");
//        ResponseEntity responseEntity = userManageEventService.userManageEventProc(userEventMsg);
//        Assert.assertEquals(SUCCESS, responseEntity.getBody().toString());
//    }
//
//    @Test
//    public void B_alertGitlabUserTest() {
//        when(userFeign.modifyGitLabUser(Mockito.anyLong(), Mockito.any(UserProcMsg.class), Mockito.anyString(), Mockito.anyInt())).thenReturn(new ResponseEntity<>(SUCCESS, HttpStatus.OK));
//        initUserEntity("UPDATE");
//        ResponseEntity responseEntity = userManageEventService.userManageEventProc(userEventMsg);
//        Assert.assertEquals(SUCCESS, responseEntity.getBody().toString());
//    }
//
//    @Test
//    public void C_deleteGitlabUserTest() {
//        when(userFeign.deleteGitLabUser(Mockito.anyLong(), Mockito.anyString())).thenReturn(new ResponseEntity<>(SUCCESS, HttpStatus.OK));
//        initUserEntity("DELETE");
//        ResponseEntity responseEntity = userManageEventService.userManageEventProc(userEventMsg);
//        Assert.assertEquals(SUCCESS, responseEntity.getBody().toString());
//    }
}
