package com.hand.hap.cloud.devops.service;

import com.hand.hap.cloud.devops.DevopsServiceApplication;
import com.hand.hap.cloud.devops.client.MemberFeign;
import com.hand.hap.cloud.devops.domain.usermember.UserMemberEventMsg;
import com.hand.hap.cloud.devops.domain.usermember.UserMemberProcMsg;
import org.junit.Assert;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.when;

//@SpringBootTest(classes = DevopsServiceApplication.class)
//@RunWith(SpringRunner.class)
//@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class UserMemberEventServiceTest {

//    private UserMemberEventMsg userMemberEventMsg = new UserMemberEventMsg();
//
//    private UserMemberProcMsg userMemberProcMsg = new UserMemberProcMsg();
//
//    //注入的对象
//    @Autowired
//    @InjectMocks
//    private UserMemberEventService userMemberEventService;
//
//    //Mock依赖注入
//    @Mock
//    private MemberFeign memberFeign;
//
//    @Before
//    public void init(){
//        //初始化Mock对象
//        MockitoAnnotations.initMocks(this);
//    }
//
//    public void setUserEventMsgValue(){
//        List<String> stringList = new ArrayList<>();
//        stringList.add("OWNER");
//        stringList.add("12244");
//        userMemberEventMsg.setProjectCreator("testuser");
//        userMemberEventMsg.setProjectId(1L);
//        userMemberEventMsg.setUsername("test1");
//        userMemberEventMsg.setUsermember(stringList);
//    }
//
//    @Test
//    public void test1() {
//        setUserEventMsgValue();
//        //Mock代理设置
//        when(memberFeign.operationGroupMember(Mockito.anyLong(),Mockito.any(UserMemberProcMsg.class)))
//                .thenReturn(new ResponseEntity<>("success",HttpStatus.OK));
//        userMemberEventMsg.setOperationType("CREATE");
//        ResponseEntity responseEntity = userMemberEventService.userMemberEventProc(userMemberEventMsg);
//        Assert.assertEquals(50, responseEntity.getBody());
//    }
//
//    @Test
//    public void test2() {
//        when(memberFeign.operationGroupMember(Mockito.anyLong(), Mockito.any(UserMemberProcMsg.class)))
//                .thenReturn(new ResponseEntity<>("success", HttpStatus.OK));
//        setUserEventMsgValue();
//        List<String> stringList = new ArrayList<>();
//        stringList.add("GUEST");
//        stringList.add("12244");
//        stringList.add("MASTER");
//        userMemberEventMsg.setUsermember(stringList);
//        userMemberEventMsg.setOperationType("UPDATE");
//        ResponseEntity responseEntity = userMemberEventService.userMemberEventProc(userMemberEventMsg);
//        Assert.assertEquals(40, responseEntity.getBody());
//    }
//
//    @Test
//    public void test3() {
//        when(memberFeign.operationGroupMember(Mockito.anyLong(), Mockito.any(UserMemberProcMsg.class)))
//                .thenReturn(new ResponseEntity<>("success", HttpStatus.OK));
//        setUserEventMsgValue();
//        List<String> stringList = new ArrayList<>();
//        stringList.add("12244");
//        stringList.add("sbciasbv");
//        userMemberEventMsg.setUsermember(stringList);
//        userMemberEventMsg.setOperationType("UPDATE");
//        ResponseEntity responseEntity = userMemberEventService.userMemberEventProc(userMemberEventMsg);
//        Assert.assertEquals(0, responseEntity.getBody());
//    }
}
