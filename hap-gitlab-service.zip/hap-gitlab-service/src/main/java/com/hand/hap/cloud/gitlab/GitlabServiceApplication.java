package com.hand.hap.cloud.gitlab;

import com.hand.hap.cloud.mybatis.MybatisMapperAutoConfiguration;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

/**
 * Created by HuangFuqiang on 2017/11/5.
 */
@EnableEurekaClient
@SpringBootApplication(exclude={DataSourceAutoConfiguration.class,MybatisMapperAutoConfiguration.class})
public class GitlabServiceApplication {

    public static void main(String[] args){
        SpringApplication.run(GitlabServiceApplication.class, args);
    }

}
