package com.hand.hap.cloud.gitlab.client;

import org.gitlab4j.api.GitLabApi;
import org.gitlab4j.api.GitLabApiException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.concurrent.ConcurrentHashMap;

/**
 * Created by zzy on 2017/11/6.
 */
@Component
public class Gitlab4jclient {

    @Value("${gitlab.url}")
    private String url;

    @Value("${gitlab.privateToken}")
    private String privateToken;

    private GitLabApi gitLabApi;
    private ConcurrentHashMap<String, GitLabApi> clientMap = new ConcurrentHashMap<>();
    public GitLabApi getGitLabApi() {
        gitLabApi = new GitLabApi(url,privateToken);
        return gitLabApi;
    }

    public GitLabApi getGitLabApi(String username) {
        GitLabApi gitLabApi = clientMap.get(username);
        if(gitLabApi!=null) {
            return  gitLabApi;
        }
        else {
            gitLabApi = new GitLabApi(url,privateToken);
            try {
                gitLabApi.sudo(username);
                clientMap.put(username,gitLabApi);
            } catch (GitLabApiException e) {
                e.printStackTrace();
            }
            return gitLabApi;
        }
    }

}
