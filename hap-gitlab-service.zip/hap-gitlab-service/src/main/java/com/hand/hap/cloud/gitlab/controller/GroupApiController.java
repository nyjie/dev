package com.hand.hap.cloud.gitlab.controller;

import com.hand.hap.cloud.gitlab.service.GroupApiService;
import com.hand.hap.cloud.resource.exception.HapException;
import io.swagger.annotations.ApiOperation;
import org.gitlab4j.api.models.Member;
import org.gitlab4j.api.models.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

/**
 * Created by qs on 2017/11/6.
 */
@RestController
@RequestMapping("/v1/project")
public class GroupApiController{

    @Autowired
    private GroupApiService groupApiService;

    /**
     *  根据username查找指定用户
     *
     * @param userName 用户名
     * @return ResponseEntity<User>
     */
    @ApiOperation(value = "根据username查找指定用户")
    @RequestMapping(value = "/user/queryUserByUsername/{userName}",method = RequestMethod.GET)
    public ResponseEntity<User> queryUserByUsername(@PathVariable String userName) {
        return Optional.ofNullable(groupApiService.queryUserByUsername(userName))
                .map(target -> new ResponseEntity<>(target, HttpStatus.OK))
                .orElseThrow(() -> new HapException("error.user.get"));
    }

    /**
     * 查找组成员信息
     * @param groupId 组ID
     * @param userId 用户ID
     * @return ResponseEntity<Member>
     */
    @ApiOperation(value = "查找组成员信息")
    @RequestMapping(value = "/select/group/{groupId}/member/{userId}",method = RequestMethod.GET)
    public ResponseEntity<Member> queryGroupMember(@PathVariable Integer groupId,
                                                   @PathVariable Integer userId) {
        Member member = groupApiService.queryGroupMember(groupId,userId);
        ResponseEntity<Member> memberResponseEntity = new ResponseEntity<>(member,HttpStatus.OK);
        return memberResponseEntity;
    }

    /**
     * 增加组成员
     * @param groupId 组ID
     * @param userId 用户ID
     * @param accessLevel 角色等级
     * @param expiresAt 权限终止时间
     * @return ResponseEntity
     */
    @ApiOperation(value = "增加组成员")
    @RequestMapping(value = "/add/groupMember",method = RequestMethod.POST)
    public ResponseEntity addMember(@RequestParam Integer groupId,
                                    @RequestParam Integer userId,
                                    @RequestParam Integer accessLevel,
                                    @RequestParam String expiresAt) {
        groupApiService.addMember(groupId,userId,accessLevel,expiresAt);
        return new ResponseEntity(HttpStatus.OK);
    }

    /**
     * 修改组成员
     * @param groupId 组ID
     * @param userId 用户ID
     * @param accessLevel 角色等级
     * @param expiresAt 权限终止时间
     * @return ResponseEntity
     */
    @ApiOperation(value = "修改组成员")
    @RequestMapping(value = "/update/groupMember",method = RequestMethod.PUT)
    public ResponseEntity updateMember(
                                    @RequestParam Integer groupId,
                                    @RequestParam Integer userId,
                                    @RequestParam Integer accessLevel,
                                    @RequestParam String expiresAt) {
        groupApiService.updateMember(groupId,userId,accessLevel,expiresAt);
        return new ResponseEntity(HttpStatus.OK);
    }

    /**
     * 移除组成员
     * @param groupId 组ID
     * @param userId 用户ID
     * @return ResponseEntity
     */
    @ApiOperation(value = "移除组成员")
    @RequestMapping(value = "/remove/group/{groupId}/member/{userId}",method = RequestMethod.DELETE)
    public ResponseEntity removeMember(@PathVariable Integer groupId,
                                       @PathVariable Integer userId) {
        groupApiService.removeMember(groupId,userId);
        return new ResponseEntity(HttpStatus.NO_CONTENT);
    }
}
