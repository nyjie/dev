package com.hand.hap.cloud.gitlab.controller;

import com.hand.hap.cloud.gitlab.service.ProjectApiService;
import com.hand.hap.cloud.resource.exception.HapException;
import io.swagger.annotations.ApiOperation;
import org.gitlab4j.api.models.Group;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;


/**
 * Created by zzy on 2017/11/6.
 */
@RestController
@RequestMapping("/v1")
public class ProjectApiController {

    @Autowired
    private ProjectApiService projectApiService;

    /**
     *  在gitlab上创建group
     * @param projectName 项目name
     * @param projectCode 项目code
     * @return 组信息
     */
    @ApiOperation(value = "创建组并返回组信息")
    @RequestMapping(value = "/organization/AddProject",method = RequestMethod.POST)
    public ResponseEntity<Group> addProject(@RequestParam String projectCode,
                            @RequestParam String projectName) {
        return Optional.ofNullable(projectApiService.addProject(projectCode,projectName))
                .map(target -> new ResponseEntity<>(target, HttpStatus.OK))
                .orElseThrow(() -> new HapException("error.group.add"));
    }

    /**
     *  在gitlab上更新group
     * @param groupId 组id
     * @param newProjectCode 新的项目code
     * @param newProjectName 新的项目name
     * @return 组信息
     */
    @ApiOperation(value = "更新组并返回组信息")
    @RequestMapping(value = "/organization/UpdateProject",method = RequestMethod.PUT)
    public ResponseEntity updateProject(@RequestParam Integer groupId,
                                        @RequestParam String newProjectCode,
                                        @RequestParam String newProjectName) {

        Group group = projectApiService.updateProject(groupId,newProjectCode,newProjectName);
        if(group!=null) {
            return new ResponseEntity(HttpStatus.OK);
        }
        else{
            return new ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     *  在gitlab上删除group
     * @param groupId 组Id
     * @return
     */
    @ApiOperation(value = "删除组")
    @RequestMapping(value = "/organization/DeleteProject",method = RequestMethod.PUT)
    public ResponseEntity deleteProject(@RequestParam Integer groupId) {
        projectApiService.deleteProject(groupId);
        return new ResponseEntity(HttpStatus.NO_CONTENT);
    }
}
