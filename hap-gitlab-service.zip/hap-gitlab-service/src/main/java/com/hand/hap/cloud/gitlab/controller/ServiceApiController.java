package com.hand.hap.cloud.gitlab.controller;

import com.hand.hap.cloud.gitlab.service.ServiceApiService;
import com.hand.hap.cloud.resource.exception.HapException;
import io.swagger.annotations.ApiOperation;
import org.gitlab4j.api.models.Project;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;


/**
 * Created by HuangFuqiang on 2017/11/7.
 */
@RestController
@RequestMapping("/v1")
public class ServiceApiController {

    @Autowired
    private ServiceApiService serviceApiService;

    /**
     * 创建项目
     *@param groupId gitlab组ID
     *@param projectName 项目名字
     *@return ResponseEntity<Project>
     */
    @ApiOperation(value = " 创建项目")
    @RequestMapping(value = "/service/createProject",method = RequestMethod.POST)
    public ResponseEntity<Project> createProject(@RequestParam Integer groupId,
                                                 @RequestParam String projectName) {
        return Optional.ofNullable(serviceApiService.createProject(groupId,projectName))
                .map(target -> new ResponseEntity<>(target, HttpStatus.OK))
                .orElseThrow(() -> new HapException("error.project.create"));
    }

    /**
     * 修改项目
     *
     *@param gitlabProjectId  gitlab的projectId
     *@param projectCode gitlab的project的name
     * @return
     */
    @ApiOperation(value = "修改项目")
    @RequestMapping(value = "/service/updateProject",method = RequestMethod.PUT)
    public ResponseEntity<Project> updateProject(@RequestParam Integer gitlabProjectId,
                                                 @RequestParam String projectCode) {
        return Optional.ofNullable(serviceApiService.updateProject(gitlabProjectId,projectCode))
                .map(target -> new ResponseEntity<>(target, HttpStatus.OK))
                .orElseThrow(() -> new HapException("error.project.update"));
    }

    /**
     * 删除项目
     *
     * @param gitlabProjectId  gitlab的projectId
     * @return ResponseEntity
     */
    @ApiOperation(value = " 删除项目")
    @RequestMapping(value = "/service/deleteProject",method = RequestMethod.DELETE)
    public ResponseEntity deleteProject(@RequestParam Integer gitlabProjectId) {
        serviceApiService.deleteProject(gitlabProjectId);
        return new ResponseEntity(HttpStatus.NO_CONTENT);
    }

    /**
     * 增加项目ci环境变量
     *
     * @param gitlabProjectId gitlab的projectId
     * @param key
     * @param value
     * @param protecteds
     * @return ResponseEntity
     */
    @ApiOperation(value = "增加项目ci环境变量")
    @RequestMapping(value = "/service/addVariable",method = RequestMethod.POST)
    public ResponseEntity addVariable(@RequestParam Integer gitlabProjectId,
                                       @RequestParam String key,
                                       @RequestParam String value,
                                       @RequestParam boolean protecteds) {
        serviceApiService.addVariable(gitlabProjectId,key,value,protecteds);
        return new ResponseEntity(HttpStatus.OK);
    }
}
