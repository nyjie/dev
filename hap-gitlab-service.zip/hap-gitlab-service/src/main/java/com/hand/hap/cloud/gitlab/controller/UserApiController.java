package com.hand.hap.cloud.gitlab.controller;

import com.hand.hap.cloud.gitlab.service.UserApiService;
import com.hand.hap.cloud.resource.exception.HapException;
import com.hand.hap.cloud.swagger.annotation.MenuLevel;
import io.swagger.annotations.ApiOperation;
import org.gitlab4j.api.models.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;


/**
 * Created by HuangFuqiang on 2017/11/6.
 */
@RestController
@RequestMapping("/v1")
public class UserApiController {

    @Autowired
    private UserApiService userApiService;

    /**
     *  用户管理，创建用户
     *
     * email (required) - Email
     * password (required) - Password
     * username (required) - Username
     * name (required) - Name
     *
     * @param user 用户
     * @param password 密码
     * @param projectsLimit 创建项目上限
     * @return ResponseEntity
     */
    @ApiOperation(value = "创建用户")
    @RequestMapping(value = "/user/create",method = RequestMethod.POST)
    public ResponseEntity createGitlabUser(@RequestBody User user,
                                           @RequestParam String password,
                                           @RequestParam Integer projectsLimit) {
        User user1 = userApiService.createGitlabUser(user,password,projectsLimit);
        if (user1 != null){
            return new ResponseEntity(HttpStatus.OK);
        }else {
            return new ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     *  用户管理，查找所有用户
     * @param perPage 每页大小
     * @param page 页数
     * @return ResponseEntity<List<User>>
     */
    @ApiOperation(value = "查找所有用户")
    @RequestMapping(value = "/user/queryAllUsers",method = RequestMethod.GET)
    public ResponseEntity<List<User>> queryAllGitlabUsers(@RequestParam(defaultValue = "5")Integer perPage,
                                                          @RequestParam(defaultValue = "0")Integer page) {
        return Optional.ofNullable(userApiService.queryAllGitlabUsers(perPage,page))
                .map(target -> new ResponseEntity<>(target, HttpStatus.OK))
                .orElseThrow(() -> new HapException("error.user.get"));
    }

    /**
     *  用户管理，查找所有active用户
     * @param perPage 每页大小
     * @param page 页数
     * @return ResponseEntity<List<User>>
     */
    @ApiOperation(value = "查找所有active用户")
    @RequestMapping(value = "/user/queryAllActiveUsers",method = RequestMethod.GET)
    public ResponseEntity<List<User>> queryAllGitlabActiveUsers(@RequestParam(defaultValue = "5")Integer perPage,
                                                                @RequestParam(defaultValue = "0")Integer page) {
        return Optional.ofNullable(userApiService.queryAllGitlabActiveUsers(perPage,page))
                .map(target -> new ResponseEntity<>(target, HttpStatus.OK))
                .orElseThrow(() -> new HapException("error.user.get"));
    }

    /**
     *  用户管理，查找当前用户
     * @return ResponseEntity<User>
     */
    @ApiOperation(value = "查找当前用户")
    @RequestMapping(value = "/user/queryCurrentUser",method = RequestMethod.GET)
    public ResponseEntity<User> queryCurrentUser() {
        return Optional.ofNullable(userApiService.queryCurrentUser())
                .map(target -> new ResponseEntity<>(target, HttpStatus.OK))
                .orElseThrow(() -> new HapException("error.user.get"));
    }

    /**
     *  用户管理，根据userid查找指定用户
     * @param userId 用户ID
     * @return ResponseEntity<User>
     */
    @ApiOperation(value = "根据userid查找指定用户")
    @RequestMapping(value = "/user/queryUserById",method = RequestMethod.GET)
    public ResponseEntity<User> queryUserById(@RequestParam Integer userId) {
        return Optional.ofNullable(userApiService.queryUserById(userId))
                .map(target -> new ResponseEntity<>(target, HttpStatus.OK))
                .orElseThrow(() -> new HapException("error.user.get"));
    }

    /**
     *  用户管理，根据username查找指定用户
     * @param userName 用户名
     * @return ResponseEntity<User>
     */
    @ApiOperation(value = "根据username查找指定用户")
    @RequestMapping(value = "/user/queryUserByUsername",method = RequestMethod.GET)
    public ResponseEntity<User> queryUserByUsername(@RequestParam String userName) {
        return Optional.ofNullable(userApiService.queryUserByUsername(userName))
                .map(target -> new ResponseEntity<>(target, HttpStatus.OK))
                .orElseThrow(() -> new HapException("error.user.get"));
    }

    /**
     *  用户管理，删除用户
     * @param username 用户ID
     * @return ResponseEntity
     */
    @ApiOperation(value = "删除用户")
    @RequestMapping(value = "/user/deleteUser",method = RequestMethod.DELETE)
    public ResponseEntity deleteUser(@RequestParam String username) {
        userApiService.deleteUser(username);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    /**
     *  用户管理，修改用户
     *
     * email (required) - Email
     * password (required) - Password
     * username (required) - Username
     * name (required) - Name
     *
     * @param user 用户
     * @param password 密码
     * @param projectsLimit 创建项目上限
     * @return ResponseEntity
     */
    @ApiOperation(value = "修改用户")
    @RequestMapping(value = "/user/alertUser",method = RequestMethod.PUT)
    public ResponseEntity alertUser(@RequestBody User user,
                                    @RequestParam String password,
                                    @RequestParam Integer projectsLimit) {
        userApiService.alertUser(user,password,projectsLimit);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
