package com.hand.hap.cloud.gitlab.domain;

/**
 * Created by qs on 2017/11/9.
 */
public class ServiceParameter {

    private String serviceName;
    private String serviceCode;
    private String serviceTypeName;
    private String serviceRepoPath;
    private String projectCode;
    private String operater;

    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    public String getServiceCode() {
        return serviceCode;
    }

    public void setServiceCode(String serviceCode) {
        this.serviceCode = serviceCode;
    }

    public String getServiceTypeName() {
        return serviceTypeName;
    }

    public void setServiceTypeName(String serviceTypeName) {
        this.serviceTypeName = serviceTypeName;
    }

    public String getServiceRepoPath() {
        return serviceRepoPath;
    }

    public void setServiceRepoPath(String serviceRepoPath) {
        this.serviceRepoPath = serviceRepoPath;
    }

    public String getProjectCode() {
        return projectCode;
    }

    public void setProjectCode(String projectCode) {
        this.projectCode = projectCode;
    }

    public String getOperater() {
        return operater;
    }

    public void setOperater(String operater) {
        this.operater = operater;
    }
}
