package com.hand.hap.cloud.gitlab.service;

import org.gitlab4j.api.models.Member;
import org.gitlab4j.api.models.User;

/**
 * Created by qs on 2017/11/6.
 */

public interface GroupApiService{

    User queryUserByUsername(String userName);

    Member queryGroupMember(Integer groupId,Integer userId);

    void addMember(Integer groupId,Integer userId,Integer accessLevel,String expiresAt);

    void updateMember(Integer groupId,Integer userId,Integer accessLevel,String expiresAt);

    void removeMember(Integer groupId,Integer userId);
}
