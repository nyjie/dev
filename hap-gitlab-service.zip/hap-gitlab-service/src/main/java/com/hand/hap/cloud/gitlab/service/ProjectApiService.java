package com.hand.hap.cloud.gitlab.service;

import org.gitlab4j.api.models.Group;

/**
 * Created by zzy on 2017/11/6.
 */
public interface ProjectApiService{

    Group addProject(String projectCode,String projectName);

    Group updateProject(Integer groupId, String newProjectCode, String newProjectName);

    void deleteProject(Integer projectId);
}
