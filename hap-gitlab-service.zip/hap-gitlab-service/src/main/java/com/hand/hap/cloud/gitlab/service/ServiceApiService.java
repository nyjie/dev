package com.hand.hap.cloud.gitlab.service;

import com.hand.hap.cloud.gitlab.domain.DevopsService;
import com.hand.hap.cloud.gitlab.domain.ServiceParameter;
import org.gitlab4j.api.models.Project;

/**
 * Created by HuangFuqiang on 2017/11/7.
 */
public interface ServiceApiService {

    Project createProject(Integer groupId, String projectName);

    Project updateProject(Integer gitlabProjectId, String projectCode);

    void deleteProject(Integer gitlabProjectId);

    void addVariable(Integer gitlabProjectId,String key,String value,boolean protecteds);
}
