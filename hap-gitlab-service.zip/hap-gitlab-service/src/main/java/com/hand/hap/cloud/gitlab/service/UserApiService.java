package com.hand.hap.cloud.gitlab.service;

import org.gitlab4j.api.models.User;

import java.util.List;

/**
 * Created by HuangFuqiang on 2017/11/6.
 */
public interface UserApiService{
    User createGitlabUser(User user,String password,Integer projectsLimit);

    List<User> queryAllGitlabActiveUsers(Integer perPage,Integer page);

    User queryCurrentUser();

    User queryUserById(Integer userId);

    User queryUserByUsername(String userName);

    List<User> queryAllGitlabUsers(Integer perPage,Integer page);

    void deleteUser(String username);

    void alertUser(User user,String password,Integer peojectsLimit);
}
