package com.hand.hap.cloud.gitlab.service.impl;


import com.hand.hap.cloud.gitlab.client.Gitlab4jclient;
import com.hand.hap.cloud.gitlab.service.GroupApiService;
import com.hand.hap.cloud.resource.exception.HapException;
import org.gitlab4j.api.GitLabApi;
import org.gitlab4j.api.GitLabApiException;
import org.gitlab4j.api.models.Member;
import org.gitlab4j.api.models.User;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Created by qs on 2017/11/6.
 */
@Service
public class GroupApiServiceImpl implements GroupApiService {

    private static final Logger logger = LoggerFactory.getLogger(GroupApiServiceImpl.class);
    private GitLabApi gitLabApi;

    @Autowired
    private Gitlab4jclient gitlab4jclient;

   public void getConnect() {
       gitLabApi = gitlab4jclient.getGitLabApi();
   }

    @Override
    public User queryUserByUsername(String userName) {
        getConnect();
        User user = null;
        try {
            user = gitLabApi.getUserApi().getUser(userName);
        }catch (GitLabApiException e){
            throw new HapException("select user is error by userName: "+userName+" , "+e.getMessage());
        }
        return user;
    }

    @Override
    public Member queryGroupMember(Integer groupId, Integer userId) {
        getConnect();
        Member member = null;
            try {
                member = gitLabApi.getGroupApi().getMember(groupId,userId);
            }catch (GitLabApiException e){
                logger.debug(e.getMessage());
            }
        return member;
    }

    @Override
    public void addMember(Integer groupId, Integer userId, Integer accessLevel, String expiresAt) {
        getConnect();
        try {
            gitLabApi.getGroupApi().addMember(groupId,userId,accessLevel,expiresAt);
        }catch (GitLabApiException e){
            throw new HapException("addMember is error: "+"groupId: "+groupId+" userId: "+userId+" accessLevel: "+accessLevel+" , "+e.getMessage());
        }
    }

    @Override
    public void updateMember(Integer groupId, Integer userId, Integer accessLevel, String expiresAt) {
        getConnect();
        try {
            gitLabApi.getGroupApi().updateMember(groupId,userId,accessLevel,expiresAt);
        }catch (GitLabApiException e){
            throw new HapException("updateMember is error: "+"groupId: "+groupId+" userId: "+userId+" accessLevel: "+accessLevel+" , "+e.getMessage());
        }
    }

    @Override
    public void removeMember(Integer groupId, Integer userId) {
        getConnect();
        try {
            gitLabApi.getGroupApi().removeMember(groupId,userId);
        }catch (GitLabApiException e){
            throw new HapException("removeMember is error: "+"groupId: "+groupId+" userId: "+userId+" , "+e.getMessage());
        }
    }
}