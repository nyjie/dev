package com.hand.hap.cloud.gitlab.service.impl;

import com.hand.hap.cloud.gitlab.client.Gitlab4jclient;
import com.hand.hap.cloud.gitlab.service.ProjectApiService;
import com.hand.hap.cloud.resource.exception.HapException;
import org.gitlab4j.api.GitLabApi;
import org.gitlab4j.api.GitLabApiException;
import org.gitlab4j.api.models.Group;
import org.gitlab4j.api.models.Visibility;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

/**
 * Created by zzy on 2017/11/6.
 */
@Service
public class ProjectApiServiceImpl implements ProjectApiService{

    @Autowired
    private Gitlab4jclient gitlab4jclient;

    @Override
    public Group addProject(String projectCode, String projectName) {
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        GitLabApi gitLabApi = gitlab4jclient.getGitLabApi(principal.toString());
      //  GitLabApi gitLabApi = gitlab4jclient.getGitLabApi("root");
        Group group = null;
        try {
            gitLabApi.getGroupApi().addGroup(projectName,projectCode,projectCode,null,
                    null, Visibility.PRIVATE,null,
                    null,null,null);
            group = gitLabApi.getGroupApi().getGroup(projectCode);
            gitLabApi.getProjectApi().createProject(group.getId(), "issue");
            if(group == null)
            {
                throw new HapException("error.group.add");
            }
        } catch (GitLabApiException e) {
            throw new HapException(e.getMessage());
        }
        return group;
    }

    @Override
    public Group updateProject(Integer groupId, String newProjectCode, String newProjectName) {
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        GitLabApi gitLabApi = gitlab4jclient.getGitLabApi(principal.toString());
       // GitLabApi gitLabApi = gitlab4jclient.getGitLabApi("root");
        Group group ;
        try {
           group = gitLabApi.getGroupApi().updateGroup(groupId,newProjectName,newProjectCode,newProjectCode,
                   null,null, Visibility.PRIVATE,null,
                   null,null,null);
        } catch (GitLabApiException e) {
            throw new HapException(e.getMessage());
        }
        return group;
    }

    @Override
    public void deleteProject(Integer groupId) {
         Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        GitLabApi gitLabApi = gitlab4jclient.getGitLabApi(principal.toString());
        try {
            gitLabApi.getGroupApi().deleteGroup(groupId);
        } catch (GitLabApiException e) {
           throw new HapException(e.getMessage());
        }
    }
}
