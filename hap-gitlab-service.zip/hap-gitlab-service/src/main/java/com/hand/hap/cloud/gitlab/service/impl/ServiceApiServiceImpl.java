package com.hand.hap.cloud.gitlab.service.impl;

import com.hand.hap.cloud.gitlab.client.Gitlab4jclient;
import com.hand.hap.cloud.gitlab.service.ServiceApiService;
import com.hand.hap.cloud.resource.exception.HapException;
import org.gitlab4j.api.GitLabApi;
import org.gitlab4j.api.GitLabApiException;
import org.gitlab4j.api.models.Project;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;


/**
 * Created by HuangFuqiang on 2017/11/7.
 */
@Service
public class ServiceApiServiceImpl implements ServiceApiService {

    private static final Logger logger = LoggerFactory.getLogger(ServiceApiServiceImpl.class);
    private GitLabApi gitLabApi;

    @Autowired
    private Gitlab4jclient gitlab4jclient;

    public void getConnect(){
      Object name =  SecurityContextHolder.getContext().getAuthentication().getPrincipal();
      gitLabApi = gitlab4jclient.getGitLabApi(String.valueOf(name));
    }

    @Override
    public Project createProject(Integer groupId, String projectName) {
        getConnect();
        Project project = null;
        try{
            project = gitLabApi.getProjectApi().createProject(groupId,projectName);
        }
        catch (GitLabApiException e){
            throw new HapException(e.getMessage());
        }
        return project;
    }

    @Override
    public Project updateProject(Integer gitlabProjectId, String projectCode) {
        getConnect();
        Project project = null;
        try{
            Project getProject = gitLabApi.getProjectApi().getProject(gitlabProjectId);
            getProject.setPath(projectCode);
            getProject.setName(projectCode);
            project = gitLabApi.getProjectApi().updateProject(getProject);
        }
        catch (GitLabApiException e){
            throw new HapException(e.getMessage());
        }
        return project;
    }

    @Override
    public void deleteProject(Integer gitlabProjectId) {
        getConnect();
        try {
            gitLabApi.getProjectApi().deleteProject(gitlabProjectId);
        }catch (GitLabApiException e){
            throw new HapException(e.getMessage());
        }
    }

    @Override
    public void addVariable(Integer gitlabProjectId, String key, String value, boolean protecteds) {
        getConnect();
        try {
            gitLabApi.getProjectApi().addVariable( gitlabProjectId, key, value, protecteds);
        }catch (GitLabApiException e){
            throw new HapException(e.getMessage());
        }
    }
}