package com.hand.hap.cloud.gitlab.service.impl;

import com.hand.hap.cloud.gitlab.client.Gitlab4jclient;
import com.hand.hap.cloud.gitlab.service.UserApiService;
import com.hand.hap.cloud.resource.exception.HapException;
import org.gitlab4j.api.GitLabApi;
import org.gitlab4j.api.GitLabApiException;
import org.gitlab4j.api.UserApi;
import org.gitlab4j.api.models.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by HuangFuqiang on 2017/11/6.
 */
@Service
public class UserApiServiceImpl implements UserApiService{

    private GitLabApi gitLabApi;

    @Autowired
    private Gitlab4jclient gitlab4jclient;

    @Override
    public User createGitlabUser(User user,String password,Integer projectsLimit) {
        gitLabApi = gitlab4jclient.getGitLabApi();
        User user1 = null;
        try {
            gitLabApi.sudo("root");
            user1 = gitLabApi.getUserApi().createUser(user,password,projectsLimit);
        }catch (GitLabApiException g){
            g.printStackTrace();
        }
        return user1;
    }

    @Override
    public List<User> queryAllGitlabActiveUsers(Integer perPage,Integer page){
        gitLabApi = gitlab4jclient.getGitLabApi();
        List<User> users = new ArrayList<>();
        try {
            gitLabApi.sudo("root");
            users = gitLabApi.getUserApi().getActiveUsers(page.intValue(),perPage.intValue());
        }catch (GitLabApiException g){
            g.printStackTrace();
        }
        return users;
    }

    @Override
    public User queryCurrentUser(){
        gitLabApi = gitlab4jclient.getGitLabApi();
        User user = null;
        try {
            gitLabApi.sudo("root");
            user = gitLabApi.getUserApi().getCurrentUser();
        }catch (GitLabApiException g){
            g.printStackTrace();
        }
        return user;
    }

    @Override
    public User queryUserById(Integer userId){
        gitLabApi = gitlab4jclient.getGitLabApi();
        User user = null;
        try {
            gitLabApi.sudo("root");
            user = gitLabApi.getUserApi().getUser(userId.intValue());
        }catch (GitLabApiException g){
            g.printStackTrace();
        }
        return user;
    }

    @Override
    public User queryUserByUsername(String userName){
        gitLabApi = gitlab4jclient.getGitLabApi();
        User user = null;
        try {
            gitLabApi.sudo("root");
            user = gitLabApi.getUserApi().getUser(userName);
        }catch (GitLabApiException g){
            g.printStackTrace();
        }
        return user;
    }

    @Override
    public List<User> queryAllGitlabUsers(Integer perPage,Integer page){
        gitLabApi = gitlab4jclient.getGitLabApi();
        List<User> users = new ArrayList<>();
        try {
            gitLabApi.sudo("root");
            UserApi userApi = gitLabApi.getUserApi();
            users = userApi.getUsers(page,perPage);
        }catch (GitLabApiException g){
            g.printStackTrace();
        }
        return users;
    }

    @Override
    public void deleteUser(String username){
        gitLabApi = gitlab4jclient.getGitLabApi();
        try {
            gitLabApi.sudo("root");
            UserApi userApi = gitLabApi.getUserApi();
            User deleteUser = userApi.getUser(username);
            userApi.deleteUser(deleteUser.getId());
        }catch (GitLabApiException g){
            throw new HapException("error.user.delete");
        }
    }

    @Override
    public void alertUser(User user,String password,Integer projectsLimit){
        gitLabApi = gitlab4jclient.getGitLabApi();
        try {
            gitLabApi.sudo("root");
            if (user.getUsername() != null){
                User userUpdate = gitLabApi.getUserApi().getUser(user.getUsername());
                if (user.getName() != null){
                    userUpdate.setName(user.getName());
                }
                if (user.getEmail() != null){
                    userUpdate.setEmail(user.getEmail());
                }
                if (user.getExternUid() != null){
                    userUpdate.setExternUid(user.getExternUid());
                }
                if (user.getProvider() != null){
                    userUpdate.setProvider(user.getProvider());
                }
                gitLabApi.getUserApi().modifyUser(userUpdate,password,projectsLimit);
            }else {
                throw new HapException("error.user.update");
            }
        }catch (GitLabApiException g){
            throw new HapException("error.user.update");
        }
    }
}
