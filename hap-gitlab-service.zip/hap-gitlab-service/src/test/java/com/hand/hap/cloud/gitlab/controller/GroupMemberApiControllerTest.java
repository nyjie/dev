package com.hand.hap.cloud.gitlab.controller;

import com.hand.hap.cloud.gitlab.HapBaseTest;
import org.gitlab4j.api.models.User;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.web.client.TestRestTemplate;

/**
 * Created by qs on 2017/11/9.
 */
//@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class GroupMemberApiControllerTest {

//    @Autowired
//    public TestRestTemplate restTemplate;
//
//    private static User target;


//    @Test
//    public void A_createGitlabUser(){
//        String name = "test"+System.currentTimeMillis();
//        String email = "test"+System.currentTimeMillis()+"@qq.com";
//        String password = "password"+System.currentTimeMillis();
//        Integer projectLimit = 100;  User user = new User();
//        user.setEmail(email);
//        user.setName(name);
//        user.setUsername(name);
//        user.setProjectsLimit(projectLimit);
//
//        ResponseEntity response = restTemplate.postForEntity("/v1/organization/{organizationId}/user/create?password="+password+"&projectsLimit="+projectLimit, user,
//                User.class, 1L);
//        Assert.assertEquals(response.getStatusCode(),HttpStatus.OK);
//
//        target = restTemplate.exchange("/v1/organization/{organizationId}/user/queryUserByUsername?userName="+name,
//                HttpMethod.GET,
//                new HttpEntity(null),
//                User.class,
//                1L).getBody();
//        Assert.assertNotNull(target);
//        Assert.assertEquals(target.getName(),name);
//    }
//
//    @Test
//    public void B_getProject(){
//        String name = "Group"+System.currentTimeMillis();
//        String path = "Group"+System.currentTimeMillis();
//
//        gitlabProject = restTemplate.exchange("/v1/project/service/getProject/{name}/{path}",
//                HttpMethod.GET,new HttpEntity(null),GitlabProject.class,name,path).getBody();
//        Assert.assertNotNull(gitlabProject);
//        Assert.assertEquals(gitlabProject.getGroupName(),name);
//    }
//
//
//    @Test
//    public void C_createGroupMember(){
//        GroupMember groupMember = new GroupMember();
//        groupMember.setGroupCreator("root");
//        groupMember.setUserName(target.getUsername());
//        groupMember.setAccessLevel(30);
//        groupMember.setExpiresAt("");
//
//        ResponseEntity response = restTemplate.postForEntity("/v1/project/{projectId}/operationGroupMember", groupMember,
//                GroupMember.class, gitlabProject.getProjectId());
//        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK);
//    }
//
//    @Test
//    public void D_updateGroupMember(){
//        GroupMember groupMember = new GroupMember();
//        groupMember.setGroupCreator("root");
//        groupMember.setUserName(target.getUsername());
//        groupMember.setAccessLevel(40);
//        groupMember.setExpiresAt("");
//
//        ResponseEntity response = restTemplate.postForEntity("/v1/project/{projectId}/operationGroupMember", groupMember,
//                GroupMember.class, gitlabProject.getProjectId());
//        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK);
//    }
//
//    @Test
//    public void E_removeGroupMember(){
//        GroupMember groupMember = new GroupMember();
//        groupMember.setGroupCreator("root");
//        groupMember.setUserName(target.getUsername());
//        groupMember.setAccessLevel(0);
//        groupMember.setExpiresAt("");
//
//        ResponseEntity response = restTemplate.postForEntity("/v1/project/{projectId}/operationGroupMember", groupMember,
//                GroupMember.class, gitlabProject.getProjectId());
//        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK);
//    }
//
//    @Test
//    public void Z_deleteProject(){
//        ResponseEntity response = restTemplate.exchange("/v1/project/service/deleteProject/{projectId}/{groupId}",
//                HttpMethod.DELETE,
//                new HttpEntity(null),
//                ResponseEntity.class,
//                gitlabProject.getId(),gitlabProject.getGroupId());
//        Assert.assertEquals(response.getStatusCode(), HttpStatus.NO_CONTENT);
//    }
//
//    @Test
//    public void Z_deleteUser(){
//        String username = target.getUsername();
//        ResponseEntity response = restTemplate.exchange("/v1/organization/{organizationId}/user/deleteUser?username="+username,
//                HttpMethod.DELETE,
//                new HttpEntity(null),
//                ResponseEntity.class,
//                1L);
//        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK);
//    }
}
