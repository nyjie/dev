package com.hand.hap.cloud.gitlab.controller;

import com.hand.hap.cloud.gitlab.HapBaseTest;
import org.gitlab4j.api.models.User;
import org.junit.Assert;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.List;

/**
 * Created by HuangFuqiang on 2017/11/7.
 */
//@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class UserApiControllerTest //extends HapBaseTest
 {

    @Autowired
    public TestRestTemplate restTemplate;

    private static User target;

//    @Test
//    public void A_createGitlabUser(){
//        String name = "test"+System.currentTimeMillis();
//        String email = "test"+System.currentTimeMillis()+"@qq.com";
//        String password = "password"+System.currentTimeMillis();
//        Integer projectLimit = 100;
//        User user = new User();
//        user.setEmail(email);
//        user.setName(name);
//        user.setUsername(name);
//        user.setProjectsLimit(projectLimit);
//
//        ResponseEntity response = restTemplate.postForEntity("/v1/organization/{organizationId}/user/create?password="+password+"&projectsLimit="+projectLimit, user,
//                User.class, 1L);
//        Assert.assertEquals(response.getStatusCode(),HttpStatus.OK);
//
//        target = restTemplate.exchange("/v1/organization/{organizationId}/user/queryUserByUsername?userName="+name,
//                HttpMethod.GET,
//                new HttpEntity(null),
//                User.class,
//                1L).getBody();
//        Assert.assertNotNull(target);
//        Assert.assertEquals(target.getName(),name);
//    }
//
//    @Test
//    public void B_queryAllGitlabUsers(){
//        List<User> users = restTemplate.exchange("/v1/organization/{organizationId}/user/queryAllUsers",
//                        HttpMethod.GET,
//                        new HttpEntity(null),
//                        List.class,
//                        1L).getBody();
//        Assert.assertFalse(users.isEmpty());
//    }
//
//    @Test
//    public void C_queryAllGitlabActiveUsers(){
//        List<User> activeUsers = restTemplate.exchange("/v1/organization/{organizationId}/user/queryAllActiveUsers",
//                HttpMethod.GET,
//                new HttpEntity(null),
//                List.class,
//                1L).getBody();
//        Assert.assertFalse(activeUsers.isEmpty());
//    }
//
//    @Test
//    public void D_queryUserById(){
//        Integer firstUserId = target.getId();
//        User user = restTemplate.exchange("/v1/organization/{organizationId}/user/queryUserById?userId="+firstUserId,
//                HttpMethod.GET,
//                new HttpEntity(null),
//                User.class,
//                1L).getBody();
//        Assert.assertEquals(target.getName(),user.getName());
//    }
//
//    @Test
//    public void E_queryUserByUsername(){
//        String userName = target.getUsername();
//        User user = restTemplate.exchange("/v1/organization/{organizationId}/user/queryUserByUsername?userName="+userName,
//                HttpMethod.GET,
//                new HttpEntity(null),
//                User.class,
//                1L).getBody();
//        Assert.assertEquals(target.getName(),user.getName());
//    }
//
//    @Test
//    public void F_queryCurrentUser(){
//        ResponseEntity response = restTemplate.exchange("/v1/organization/{organizationId}/user/queryCurrentUser",
//                HttpMethod.GET,
//                new HttpEntity(null),
//                User.class,
//                1L);
//        Assert.assertEquals(response.getStatusCode(),HttpStatus.OK);
//    }
//
//    @Test
//    public void G_alertUser(){
//        String name  = "test"+System.currentTimeMillis();
//        target.setName(name);
//        String password = "password1"+System.currentTimeMillis();
//        Integer projectsLimit = 101;
//        ResponseEntity responseEntity = restTemplate.exchange("/v1/organization/{organizationId}/user/alertUser?password="+password+"&projectsLimit="+projectsLimit,
//                HttpMethod.PUT,
//                new HttpEntity(target),
//                User.class,
//                1L);
//        Assert.assertEquals(responseEntity.getStatusCode(),HttpStatus.OK);
//        Integer firstUserId = target.getId();
//        User user = restTemplate.exchange("/v1/organization/{organizationId}/user/queryUserById?userId="+firstUserId,
//                HttpMethod.GET,
//                new HttpEntity(null),
//                User.class,
//                1L).getBody();
//        Assert.assertEquals(name,user.getName());
//    }
//
//
//    @Test
//    public void Z_deleteUser(){
//        String username = target.getUsername();
//        ResponseEntity response = restTemplate.exchange("/v1/organization/{organizationId}/user/deleteUser?username="+username,
//                HttpMethod.DELETE,
//                new HttpEntity(null),
//                ResponseEntity.class,
//                1L);
//        Assert.assertEquals(response.getStatusCode(), HttpStatus.OK);
//    }


}
