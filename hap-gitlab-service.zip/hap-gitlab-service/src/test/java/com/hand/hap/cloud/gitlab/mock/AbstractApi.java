package com.hand.hap.cloud.gitlab.mock;

import org.gitlab4j.api.Constants;
import org.gitlab4j.api.GitLabApi;
import org.gitlab4j.api.GitLabApiClient;
import org.gitlab4j.api.GitLabApiException;

import javax.ws.rs.core.Form;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;
import java.net.URL;

public class AbstractApi extends org.gitlab4j.api.AbstractApi implements Constants {
    public AbstractApi(GitLabApi gitLabApi) {
        super(gitLabApi);
    }

    @Override
    protected GitLabApi.ApiVersion getApiVersion() {
        return super.getApiVersion();
    }

    @Override
    protected boolean isApiVersion(GitLabApi.ApiVersion apiVersion) {
        return super.isApiVersion(apiVersion);
    }

    @Override
    protected int getDefaultPerPage() {
        return super.getDefaultPerPage();
    }

    @Override
    protected GitLabApiClient getApiClient() {
        return super.getApiClient();
    }

    @Override
    protected String urlEncode(String s) throws GitLabApiException {
        return super.urlEncode(s);
    }

    @Override
    protected Response get(Response.Status expectedStatus, MultivaluedMap<String, String> queryParams, Object... pathArgs) throws GitLabApiException {
        return super.get(expectedStatus, queryParams, pathArgs);
    }

    @Override
    protected Response getWithAccepts(Response.Status expectedStatus, MultivaluedMap<String, String> queryParams, String accepts, Object... pathArgs) throws GitLabApiException {
        return super.getWithAccepts(expectedStatus, queryParams, accepts, pathArgs);
    }

    @Override
    protected Response get(Response.Status expectedStatus, MultivaluedMap<String, String> queryParams, URL url) throws GitLabApiException {
        return super.get(expectedStatus, queryParams, url);
    }

    @Override
    protected Response post(Response.Status expectedStatus, Form formData, Object... pathArgs) throws GitLabApiException {
        return super.post(expectedStatus, formData, pathArgs);
    }

    @Override
    protected Response post(Response.Status expectedStatus, MultivaluedMap<String, String> queryParams, Object... pathArgs) throws GitLabApiException {
        return super.post(expectedStatus, queryParams, pathArgs);
    }

    @Override
    protected Response post(Response.Status expectedStatus, Form formData, URL url) throws GitLabApiException {
        return super.post(expectedStatus, formData, url);
    }

    @Override
    protected Response put(Response.Status expectedStatus, MultivaluedMap<String, String> queryParams, Object... pathArgs) throws GitLabApiException {
        return super.put(expectedStatus, queryParams, pathArgs);
    }

    @Override
    protected Response put(Response.Status expectedStatus, MultivaluedMap<String, String> queryParams, URL url) throws GitLabApiException {
        return super.put(expectedStatus, queryParams, url);
    }

    @Override
    protected Response putWithFormData(Response.Status expectedStatus, Form formData, Object... pathArgs) throws GitLabApiException {
        return super.putWithFormData(expectedStatus, formData, pathArgs);
    }

    @Override
    protected Response delete(Response.Status expectedStatus, MultivaluedMap<String, String> queryParams, Object... pathArgs) throws GitLabApiException {
        return super.delete(expectedStatus, queryParams, pathArgs);
    }

    @Override
    protected Response delete(Response.Status expectedStatus, MultivaluedMap<String, String> queryParams, URL url) throws GitLabApiException {
        return super.delete(expectedStatus, queryParams, url);
    }

    @Override
    protected void addFormParam(Form formData, String name, Object value) throws IllegalArgumentException {
        super.addFormParam(formData, name, value);
    }

    @Override
    protected void addFormParam(Form formData, String name, Object value, boolean required) throws IllegalArgumentException {
        super.addFormParam(formData, name, value, required);
    }

    @Override
    protected Response validate(Response response, Response.Status expected) throws GitLabApiException {
        return super.validate(response, expected);
    }

    @Override
    protected GitLabApiException handle(Exception thrown) {
        return super.handle(thrown);
    }

    @Override
    protected MultivaluedMap<String, String> getPageQueryParams(int page, int perPage) {
        return super.getPageQueryParams(page, perPage);
    }

    @Override
    protected MultivaluedMap<String, String> getDefaultPerPageParam() {
        return super.getDefaultPerPageParam();
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        return super.equals(obj);
    }

    @Override
    protected Object clone() throws CloneNotSupportedException {
        return super.clone();
    }

    @Override
    public String toString() {
        return super.toString();
    }

    @Override
    protected void finalize() throws Throwable {
        super.finalize();
    }
}
