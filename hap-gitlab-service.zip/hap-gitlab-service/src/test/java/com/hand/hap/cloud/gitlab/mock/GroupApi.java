package com.hand.hap.cloud.gitlab.mock;

import org.gitlab4j.api.GitLabApi;
import org.gitlab4j.api.GitLabApiException;
import org.gitlab4j.api.Pager;
import org.gitlab4j.api.models.Group;
import org.gitlab4j.api.models.Member;
import org.gitlab4j.api.models.Project;
import org.gitlab4j.api.models.Visibility;

import java.util.List;

public class GroupApi extends org.gitlab4j.api.GroupApi {
    public GroupApi(GitLabApi gitLabApi) {
        super(gitLabApi);
    }

    @Override
    public List<Group> getGroups() throws GitLabApiException {
        return super.getGroups();
    }

    @Override
    public List<Group> getGroups(int page, int perPage) throws GitLabApiException {
        return super.getGroups(page, perPage);
    }

    @Override
    public Pager<Group> getGroups(int itemsPerPage) throws GitLabApiException {
        return super.getGroups(itemsPerPage);
    }

    @Override
    public List<Group> getGroups(String search) throws GitLabApiException {
        return super.getGroups(search);
    }

    @Override
    public List<Group> getGroups(String search, int page, int perPage) throws GitLabApiException {
        return super.getGroups(search, page, perPage);
    }

    @Override
    public Pager<Group> getGroups(String search, int itemsPerPage) throws GitLabApiException {
        return super.getGroups(search, itemsPerPage);
    }

    @Override
    public List<Project> getProjects(int groupId) throws GitLabApiException {
        return super.getProjects(groupId);
    }

    @Override
    public List<Project> getProjects(int groupId, int page, int perPage) throws GitLabApiException {
        return super.getProjects(groupId, page, perPage);
    }

    @Override
    public Pager<Project> getProjects(int groupId, int itemsPerPage) throws GitLabApiException {
        return super.getProjects(groupId, itemsPerPage);
    }

    @Override
    public Group getGroup(Integer groupId) throws GitLabApiException {
        return super.getGroup(groupId);
    }

    @Override
    public Group getGroup(String groupPath) throws GitLabApiException {
        return super.getGroup(groupPath);
    }

    @Override
    public void addGroup(String name, String path) throws GitLabApiException {
        super.addGroup(name, path);
    }

    @Override
    public void addGroup(String name, String path, String description, Boolean membershipLock, Boolean shareWithGroupLock, Visibility visibility, Boolean lfsEnabled, Boolean requestAccessEnabled, Integer parentId, Integer sharedRunnersMinutesLimit) throws GitLabApiException {
        super.addGroup(name, path, description, membershipLock, shareWithGroupLock, visibility, lfsEnabled, requestAccessEnabled, parentId, sharedRunnersMinutesLimit);
    }

    @Override
    public Group updateGroup(Integer groupId, String name, String path, String description, Boolean membershipLock, Boolean shareWithGroupLock, Visibility visibility, Boolean lfsEnabled, Boolean requestAccessEnabled, Integer parentId, Integer sharedRunnersMinutesLimit) throws GitLabApiException {
        return super.updateGroup(groupId, name, path, description, membershipLock, shareWithGroupLock, visibility, lfsEnabled, requestAccessEnabled, parentId, sharedRunnersMinutesLimit);
    }

    @Override
    public void deleteGroup(Integer groupId) throws GitLabApiException {
        super.deleteGroup(groupId);
    }

    @Override
    public void deleteGroup(Group group) throws GitLabApiException {
        super.deleteGroup(group);
    }

    @Override
    public List<Member> getMembers(int groupId) throws GitLabApiException {
        return super.getMembers(groupId);
    }

    @Override
    public Member getMember(int groupId, int userId) throws GitLabApiException {
        return super.getMember(groupId, userId);
    }

    @Override
    public Member addMember(Integer groupId, Integer userId, Integer accessLevel, String expires_at) throws GitLabApiException {
        return super.addMember(groupId, userId, accessLevel, expires_at);
    }

    @Override
    public Member updateMember(int groupId, int userId, int access_level, String expires_at) throws GitLabApiException {
        return super.updateMember(groupId, userId, access_level, expires_at);
    }

    @Override
    public List<Member> getMembers(int groupId, int page, int perPage) throws GitLabApiException {
        return super.getMembers(groupId, page, perPage);
    }

    @Override
    public Pager<Member> getMembers(int groupId, int itemsPerPage) throws GitLabApiException {
        return super.getMembers(groupId, itemsPerPage);
    }

    @Override
    public Member addMember(Integer groupId, Integer userId, Integer accessLevel) throws GitLabApiException {
        return super.addMember(groupId, userId, accessLevel);
    }

    @Override
    public void removeMember(Integer projectId, Integer userId) throws GitLabApiException {
        super.removeMember(projectId, userId);
    }
}
