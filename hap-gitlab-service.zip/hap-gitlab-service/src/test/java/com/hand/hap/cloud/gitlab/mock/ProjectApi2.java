package com.hand.hap.cloud.gitlab.mock;


import org.gitlab4j.api.GitLabApi;


public class ProjectApi2 extends org.gitlab4j.api.ProjectApi {
    public ProjectApi2(GitLabApi gitLabApi) {
        super(gitLabApi);
    }


}
