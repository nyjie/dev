package com.hand.hap.cloud.gitlab.mock;

import org.springframework.security.core.context.SecurityContext;
//import org.springframework.security.core.context.SecurityContextHolder;

public class SecurityContextHolder extends org.springframework.security.core.context.SecurityContextHolder {
    public SecurityContextHolder(){
        super();
    }


    public static SecurityContext getContext(){
        return org.springframework.security.core.context.SecurityContextHolder.getContext();
    }

}
