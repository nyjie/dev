package com.hand.hap.cloud.gitlab.mock;

import org.gitlab4j.api.Constants;
import org.gitlab4j.api.GitLabApi;
import org.gitlab4j.api.GitLabApiException;
import org.gitlab4j.api.Pager;
import org.gitlab4j.api.models.ImpersonationToken;
import org.gitlab4j.api.models.SshKey;
import org.gitlab4j.api.models.User;

import java.util.Date;
import java.util.List;

public class UserApi extends org.gitlab4j.api.UserApi{
    public UserApi(GitLabApi gitLabApi) {
        super(gitLabApi);
    }

    @Override
    public List<User> getUsers() throws GitLabApiException {
        return super.getUsers();
    }

    @Override
    public List<User> getUsers(int page, int perPage) throws GitLabApiException {
        return super.getUsers(page, perPage);
    }

    @Override
    public Pager<User> getUsers(int itemsPerPage) throws GitLabApiException {
        return super.getUsers(itemsPerPage);
    }

    @Override
    public List<User> getActiveUsers() throws GitLabApiException {
        return super.getActiveUsers();
    }

    @Override
    public List<User> getActiveUsers(int page, int perPage) throws GitLabApiException {
        return super.getActiveUsers(page, perPage);
    }

    @Override
    public Pager<User> getActiveUsers(int itemsPerPage) throws GitLabApiException {
        return super.getActiveUsers(itemsPerPage);
    }

    @Override
    public User blockUser(Integer userId) throws GitLabApiException {
        return super.blockUser(userId);
    }

    @Override
    public User unblockUser(Integer userId) throws GitLabApiException {
        return super.unblockUser(userId);
    }

    @Override
    public List<User> getBlockedUsers() throws GitLabApiException {
        return super.getBlockedUsers();
    }

    @Override
    public List<User> getblockedUsers(int page, int perPage) throws GitLabApiException {
        return super.getblockedUsers(page, perPage);
    }

    @Override
    public Pager<User> getBlockedUsers(int itemsPerPage) throws GitLabApiException {
        return super.getBlockedUsers(itemsPerPage);
    }

    @Override
    public User getUser(int userId) throws GitLabApiException {
        return super.getUser(userId);
    }

    @Override
    public User getUser(String username) throws GitLabApiException {
        return super.getUser(username);
    }

    @Override
    public List<User> findUsers(String emailOrUsername) throws GitLabApiException {
        return super.findUsers(emailOrUsername);
    }

    @Override
    public List<User> findUsers(String emailOrUsername, int page, int perPage) throws GitLabApiException {
        return super.findUsers(emailOrUsername, page, perPage);
    }

    @Override
    public Pager<User> findUsers(String emailOrUsername, int itemsPerPage) throws GitLabApiException {
        return super.findUsers(emailOrUsername, itemsPerPage);
    }

    @Override
    public User createUser(User user, String password, Integer projectsLimit) throws GitLabApiException {
        return super.createUser(user, password, projectsLimit);
    }

    @Override
    public User modifyUser(User user, String password, Integer projectsLimit) throws GitLabApiException {
        return super.modifyUser(user, password, projectsLimit);
    }

    @Override
    public void deleteUser(Integer userId) throws GitLabApiException {
        super.deleteUser(userId);
    }

    @Override
    public void deleteUser(User user) throws GitLabApiException {
        super.deleteUser(user);
    }

    @Override
    public User getCurrentUser() throws GitLabApiException {
        return super.getCurrentUser();
    }

    @Override
    public List<SshKey> getSshKeys() throws GitLabApiException {
        return super.getSshKeys();
    }

    @Override
    public List<SshKey> getSshKeys(Integer userId) throws GitLabApiException {
        return super.getSshKeys(userId);
    }

    @Override
    public SshKey getSshKey(Integer keyId) throws GitLabApiException {
        return super.getSshKey(keyId);
    }

    @Override
    public SshKey addSshKey(String title, String key) throws GitLabApiException {
        return super.addSshKey(title, key);
    }

    @Override
    public SshKey addSshKey(Integer userId, String title, String key) throws GitLabApiException {
        return super.addSshKey(userId, title, key);
    }

    @Override
    public void deleteSshKey(Integer keyId) throws GitLabApiException {
        super.deleteSshKey(keyId);
    }

    @Override
    public void deleteSshKey(Integer userId, Integer keyId) throws GitLabApiException {
        super.deleteSshKey(userId, keyId);
    }

    @Override
    public List<ImpersonationToken> getImpersonationTokens(Integer userId) throws GitLabApiException {
        return super.getImpersonationTokens(userId);
    }

    @Override
    public List<ImpersonationToken> getImpersonationTokens(Integer userId, ImpersonationState state) throws GitLabApiException {
        return super.getImpersonationTokens(userId, state);
    }

    @Override
    public ImpersonationToken getImpersonationToken(Integer userId, Integer tokenId) throws GitLabApiException {
        return super.getImpersonationToken(userId, tokenId);
    }

    @Override
    public ImpersonationToken createImpersonationToken(Integer userId, String name, Date expiresAt, ImpersonationToken.Scope[] scopes) throws GitLabApiException {
        return super.createImpersonationToken(userId, name, expiresAt, scopes);
    }

    @Override
    public void revokeImpersonationToken(Integer userId, Integer tokenId) throws GitLabApiException {
        super.revokeImpersonationToken(userId, tokenId);
    }
}
