package com.hand.hap.cloud.gitlab.service;


import com.hand.hap.cloud.gitlab.GitlabServiceApplication;
import com.hand.hap.cloud.gitlab.client.Gitlab4jclient;

import com.hand.hap.cloud.gitlab.mock.GroupApi;
import com.hand.hap.cloud.gitlab.mock.ProjectApi2;
//import com.hand.hap.cloud.gitlab.mock.SecurityContextHolder;
import org.gitlab4j.api.GitLabApi;
import org.gitlab4j.api.GitLabApiException;
//import org.gitlab4j.api.GroupApi;
import org.gitlab4j.api.models.Group;
import org.gitlab4j.api.models.Project;
import org.gitlab4j.api.models.Visibility;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.mockito.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.context.SecurityContextImpl;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.*;

@SpringBootTest(classes = GitlabServiceApplication.class)
@RunWith(SpringRunner.class)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ProjectApiServiceTest {

    @Autowired
    @InjectMocks
    ProjectApiService projectApiService;

    @Mock
    Gitlab4jclient gitlab4jclient;

    @Before
    public void init(){
        MockitoAnnotations.initMocks(this);
    }
    /*
    注：mock测试之前，ProjectApiServiceImpl 里从上下文获取用户名暂时无法代理，这两行：
     Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        GitLabApi gitLabApi = gitlab4jclient.getGitLabApi(principal.toString());
        注释掉，用固定用户名的方式代替：
         GitLabApi gitLabApi = gitlab4jclient.getGitLabApi("root");
     */
    @Test
    public void a_add() {
        String projectCode="as";
        String projectName="as";
       // String username="root";
       // Long projectId=12L;

        Group group=new Group();
        group.setName("sa");
        group.setId(10);

        GitLabApi gitLabApi=mock(GitLabApi.class);
        when(gitlab4jclient.getGitLabApi(Mockito.anyString())).thenReturn(gitLabApi);

        GroupApi groupApi=mock(GroupApi.class);
        when(gitLabApi.getGroupApi()).thenReturn(groupApi);
        try {
            when(groupApi.getGroup(Mockito.anyString())).thenReturn(group);
        } catch (GitLabApiException e) {
            e.printStackTrace();
        }

        ProjectApi2 projectApi=mock(ProjectApi2.class);
        when(gitLabApi.getProjectApi()).thenReturn(projectApi);
        try {
            when(projectApi.createProject(Mockito.anyInt(),Mockito.anyString())).thenReturn(new Project());
        } catch (GitLabApiException e) {
            e.printStackTrace();
        }
        projectApiService.addProject(projectCode,projectName);

        try {
            verify(groupApi,times(1)).addGroup(projectName,projectCode,projectCode,
                    null,null, Visibility.PRIVATE,
                    null,null,null,null);
        } catch (GitLabApiException e) {
            e.printStackTrace();
        }
    }
    @Test
    public void b_update(){
        Integer groupId=100;
        String newProjectCode="as100";
        String newProjectName="as100";
        GitLabApi gitLabApi=mock(GitLabApi.class);
        when(gitlab4jclient.getGitLabApi(Mockito.anyString())).thenReturn(gitLabApi);
        GroupApi groupApi=mock(GroupApi.class);
        when(gitLabApi.getGroupApi()).thenReturn(groupApi);
        Group group=new Group();
        group.setName("sa");
        group.setId(5);
        try {
            when(groupApi.getGroup(Mockito.anyString())).thenReturn(group);
        } catch (GitLabApiException e) {
            e.printStackTrace();
        }
        projectApiService.updateProject(groupId,newProjectCode,newProjectName);
        try {
            verify(groupApi).updateGroup(groupId,newProjectName,newProjectCode,newProjectCode,
                    null,null, Visibility.PRIVATE,null,
                    null,null,null);
        } catch (GitLabApiException e) {
            e.printStackTrace();
        }
    }
    @Test
    public void c_delete(){
        Integer groupId=1000;
        GitLabApi gitLabApi=mock(GitLabApi.class);
        when(gitlab4jclient.getGitLabApi(Mockito.anyString())).thenReturn(gitLabApi);
        GroupApi groupApi=mock(GroupApi.class);
        when(gitLabApi.getGroupApi()).thenReturn(groupApi);
        projectApiService.deleteProject(groupId);
        try {
            verify(groupApi,times(1)).deleteGroup(groupId);
        } catch (GitLabApiException e) {
            e.printStackTrace();
        }
    }
}
