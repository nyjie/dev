package com.hand.hap.cloud.gitlab.service;

/**
 * Created by HuangFuqiang on 2017/11/13.
 */
public class UserApiServiceTest {
}
